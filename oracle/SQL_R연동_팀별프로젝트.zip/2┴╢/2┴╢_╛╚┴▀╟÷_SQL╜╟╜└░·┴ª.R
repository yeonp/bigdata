Sys.setenv(JAVA_HOME="C:/Program Files/Java/jre1.8.0_211")
install.packages("rJava")
install.packages("RJDBC")

library(rJava)
library(RJDBC)

drv <- JDBC("oracle.jdbc.driver.OracleDriver","C:/app/CPB06GameN/product/11.2.0/dbhome_1/jdbc/lib/ojdbc6.jar")

conn<- dbConnect(drv,
                 "jdbc:oracle:thin:localhost:1512:orcl",
                 "SCOTT","tiger")

query <- "select * from MAN"
query

result <- dbGetQuery(conn,query)

head(result)

dbDisconnect(conn)

# dbListTables(conn)

library(foreign)
library(dplyr)
library(ggplot2)
library(readxl)

df_problem <- read_excel("MARRIED_PROBLEM.xlsx")
df_problem

# 부부폭력이 일어나게 된 이유(피해자 입장)
gg <- ggplot(df_problem, aes(x=1:nrow(df_problem), y=MAN_VICTIM)) + 
      xlim(df_problem$PROBLEM) + 
      theme(plot.title = element_text(family="serif", face=4, hjust=0.5, 
                                      size =30, color="darkblue")) +
      theme(axis.title =element_text(face=4, size=20),
            axis.text.x=element_text(face=4, size=11, angle=11), 
            axis.text.y=element_text(face=4, size=11)) 

gg + geom_line(linetype= 4, size=1.3, colour="darkblue", lineend='round') +
     geom_line(aes(x=1:nrow(df_problem), y=WOMAN_VICTIM), 
               linetype= 4, size=1.3, colour="red") +
     labs(x="유형별", y="count(빈도)", title="부부폭력이 일어나게 된 이유(피해자 입장)")

# 부부폭력이 일어나게 된 이유(가해자 입장) 
gg2 <- ggplot(df_problem, aes(x=1:nrow(df_problem), y=MAN_ATTACKER)) +
       xlim(df_problem$PROBLEM) + 
       theme(plot.title = element_text(family="serif", face=4, hjust=0.5, 
                                       size =30, color="darkblue")) +
       theme(axis.title =element_text(face=4, size=20),
             axis.text.x=element_text(face=4, size=11, angle=11), 
             axis.text.y=element_text(face=4, size=11))

gg2 + geom_line(linetype= 4, size=1.3, colour="darkblue", lineend='round') +
      geom_line(aes(x=1:nrow(df_problem), y=WOMAN_ATTACKER), 
                linetype= 4, size=1.3, color="red") +
      labs(x="유형별", y="count(빈도)", title="부부폭력이 일어나게 된 이유(가해자 입장)")

# 부부폭력이 일어나게 된 이유(통합)
gg <- ggplot(df_problem, aes(x=1 :nrow(df_problem), y=MAN_VICTIM)) + 
      xlim(df_problem$PROBLEM) +  
      theme(plot.title = element_text(family="serif", face=4, hjust=0.5, 
                                   size =30, color="darkblue")) + 
      theme(axis.title =element_text(face=4, size=20),
            axis.text.x=element_text(face=4, size=11, angle=11), 
            axis.text.y=element_text(face=4, size=11))

gg + geom_line(linetype= 4, size=1.3, colour="darkblue", lineend='round') +  
     geom_line(aes(x=1:nrow(df_problem), y=WOMAN_VICTIM), 
               linetype= 4, size=1.3, color="red", lineend='round') +   
     geom_line(aes(x=1:nrow(df_problem), y=MAN_ATTACKER), 
               linetype= 4, size=1.3, color="green", lineend='round') + 
     geom_line(aes(x=1:nrow(df_problem), y=WOMAN_ATTACKER), 
               linetype= 4, size=1.3, color="pink", lineend='round') + 
     labs(x="유형별", y="count(빈도)", title="부부폭력이 일어나게 된 이유(통합)")
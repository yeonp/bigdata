﻿

-- 4조 SQL 엑셀 읽어들이기, 외래키 사용하기, 조인 하기

CREATE TABLE CODE(
    CITICODE        NUMBER(20)      PRIMARY KEY NOT NULL,
    CITINAME        VARCHAR2(20)     NOT NULL
);
SELECT * FROM code;

CREATE TABLE GAMGI(
    IND             number(10)  NOT NULL,
    GDATE           DATE        NOT NULL,
    CCODE           NUMBER(20)  CONSTRAINT FOREIN2 REFERENCES CODE(CITICODE),
    GUNSU           NUMBER(4)   NOT NULL
);
SELECT * FROM GAMGI;
-- FORIEN 설정

--엑셀 데이터 읽어들이기


SELECT 
    G.GDATE, G.CCODE, C.CITICODE, C.CITINAME, G.GUNSU
FROM CODE C, GAMGI G
WHERE C.CITICODE = G.CCODE;

-- GAMGI의 CCODE(외래키)와 CODE의 CITICODE(부모키)
-- 지역명을 조인





--어러웠던 점은 외래키에 있는 데이터가 부모키에 없어 
-- 토드에서 엑셀파일을 불었을때 무결성을 지키지 못했습니다.

-- 전처리를 통해 외래키에 없는 데이터를 부모키에서 삭제 후 IMPORT 하였습니다.

--어떤 조인을 사용해야 할지 어려웠습니다.

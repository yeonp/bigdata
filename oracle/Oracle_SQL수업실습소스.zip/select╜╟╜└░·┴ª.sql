--SELECT��_�ǽ�����.sql
-- sample DB ��ġ Ȯ�� �ϱ�   
SELECT *
FROM Student;

SELECT * FROM 
EC_Basket;

SELECT * FROM USER_CATALOG;


--1��
SELECT Product_Code, Product_Name, Unit_Price
FROM   EC_Product
WHERE  Unit_Price > 2000000;

--2��
SELECT UserID, Name, Regist_NO, Address
FROM   EC_Member
WHERE  Address LIKE '����%';

SELECT *
FROM   EC_Basket;

DESC EC_Basket;
--3��
SELECT *
FROM   EC_Basket
WHERE  Order_Date Like '10/11/06';

SELECT *
FROM   EC_ORDER;

--4��
SELECT ORDER_NO, PRODUCT_CODE,ORDER_QTY, CSEL,
       CMONEY, CDATE, GUBUN
FROM   EC_ORDER
WHERE  GUBUN = '����' AND MDATE IS NULL;

--5��
SELECT UserID, Name, Regist_No
FROM   EC_Member
WHERE  Name Like '%��%';

--6��
SELECT Order_No, Order_ID, Product_Code, Csel, Gubun
FROM   EC_Order
WHERE  NOT Csel = '�ſ�ī��' AND Mdate IS NOT NULL
ORDER BY Order_ID;

--7��
SELECT Product_Code, Product_Name, Unit_Price, Left_Qty, Company
FROM   EC_Product
WHERE  Unit_Price BETWEEN 300000 AND 500000
ORDER  BY  Unit_Price DESC;

--8��
SELECT ORDER_NO, ORDER_ID, PRODUCT_CODE, CMONEY, CDATE, CSEL
FROM   EC_Order
WHERE  Csel = '�ſ�ī��';

--9��
SELECT ORDER_NO, ORDER_ID, PRODUCT_CODE,ORDER_QTY,CMONEY, GUBUN
FROM   EC_Order
WHERE  Csel IS NULL;

--10��
SELECT Order_ID,Product_Code,Order_Qty,Csel,Cmoney, Gubun
FROM   EC_Order
WHERE  Order_ID = 'usko';

/**********************************************************
*  ���̺� ����
***********************************************************/
DROP TABLE SG_Scores;
DROP TABLE Student;
DROP TABLE Course;
DROP TABLE Professor;
DROP TABLE Department;
DROP TABLE Course_Temp;
DROP TABLE SCORE_GRADE;
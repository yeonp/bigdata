# 08-2.R
# R 시각화

# 산점도: Scatter Plot, 두변수간의 상관 관계 
library(ggplot2)

# aes: aesthetic mapping
# 1단계 : 배경 화면 출력, 배경 생성 
ggplot(data=mpg, aes(x=displ , y=hwy))

# 2단계 : 산점도 추가
ggplot(data=mpg, aes(x=displ , y=hwy)) + geom_point()

# 3단계  : x,y축의 범위 지정 
ggplot(data=mpg, aes(x=displ , y=hwy)) + 
  geom_point(colour='red') + 
  xlim(3,6) + 
  ylim(10,30)

#plot(iris$Sepal.Length,iris$Sepal.Width)

qplot(manufacturer, data = mpg, geom="bar",
      fill=manufacturer)

# 문제 1
ggplot(data=mpg, aes(x=cty , y=hwy)) + geom_point(colour='blue')

# 문제 2
ggplot(data=midwest, aes(x=poptotal , y=popasian)) + 
  geom_point(colour='darkgreen') + 
  xlim(0,500000) + 
  ylim(0,10000)

# 막대그래프 : Bar Chart,여러 집단 간의 차이 
library(dplyr)
df_mpg <- mpg %>%
          group_by(drv) %>%
          summarise(mean_hwy=mean(hwy)) %>%
          arrange(desc(mean_hwy))
df_mpg

ggplot(data=df_mpg,aes(x=drv,y=mean_hwy)) + geom_col()

ggplot(data=df_mpg,aes(x=reorder(drv,-mean_hwy),y=mean_hwy)) + geom_col()

# 빈도 막대 그래프 
ggplot(data=mpg,aes(x= drv)) + geom_bar()

ggplot(data=mpg,aes(x= manufacturer)) + geom_bar()



# 문제 1
# 평균 표 생성
df <- mpg %>%
  filter(class == "suv") %>%
  group_by(manufacturer) %>%
  summarise(mean_cty = mean(cty)) %>%
  arrange(desc(mean_cty)) %>%
  head(5)

# 그래프 생성
ggplot(data = df, aes(x = reorder(manufacturer, -mean_cty),
                      y = mean_cty)) + geom_col()

# 문제2 
ggplot(data = mpg, aes(x = class)) + geom_bar()



# 선 그래프 : Line Chart, 시계열데이터(Time Series Data)

ggplot(data=economics,aes(x=date, y=unemploy)) + geom_line()

#문제 1
ggplot(data=economics,aes(x=date, y=psavert)) + geom_line()


# 상자 그림 : Box Plot, 데이터의 분포(사분위수)
ggplot(data= mpg,aes(x=drv,y=hwy)) + geom_boxplot()


# 문제 1
class_mpg <- mpg %>% 
  filter(class %in% c("compact", "subcompact", "suv"))

ggplot(data = class_mpg, aes(x = class, y = cty)) + geom_boxplot()




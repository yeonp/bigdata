# 09-1.R
# 한국복지패널데이터 분석

#install.packages("foreign")

library(foreign)
library(dplyr)
library(ggplot2)
library(readxl)

# 통계 파일 불러 오기 
raw_welfare <- read.spss(file="Koweps_hpc10_2015_beta1.sav", to.data.frame = T)

# 데이터 프레임 사본 생성 
welfare <- raw_welfare

head(welfare)
str(welfare)
dim(welfare)   # 16664   957
#View(welfare)
summary(welfare)

# 변수명 변경
welfare <- rename(welfare,
                  sex = h10_g3,
                  birth = h10_g4,
                  marriage = h10_g10,
                  religion = h10_g11,
                  income = p1002_8aq1,
                  code_job = h10_eco9,
                  code_region = h10_reg7)


str(welfare)
#View(welfare)
welfare$income
raw_welfare$p1002_8aq1

# 09-2 (1) 성별에 따른 월급 차이 분석

# 성별  welfare$sex 변수 검토 및 전처리 
class(welfare$sex) # [1] "numeric"
table(welfare$sex)

# 이상치의 결측 처리 
welfare$sex <- ifelse(welfare$sex == 9, NA, welfare$sex)

table(is.na(welfare$sex))

welfare$sex <- ifelse(welfare$sex == 1,"male","female")
welfare$sex
table(welfare$sex)
str(welfare$sex)
qplot(welfare$sex)

# 월급 welfare$income 변수 검토 및 전처리 
class(welfare$income)
summary(welfare$income)
qplot(welfare$income)

qplot(welfare$income) + xlim(0,1000)

boxplot(welfare$income)$stats

summary(welfare$income)

# 이상치 결측처리 :  0,9999
welfare$income <- ifelse(welfare$income %in% c(0,9999),NA,welfare$income)
table(is.na(welfare$income))


# 성별에 따른 월급차이
sex_income <- welfare %>%
               filter(!is.na(income)) %>%
               group_by(sex) %>%
               summarise(mean_income=mean(income))

sex_income

# 그래프로 출력, 보고서
ggplot(data=sex_income, aes(x=sex,y=mean_income)) + geom_col()



# 09-3 (2) 나이와 월급 차이 분석

class(welfare$birth)
summary(welfare$birth)
qplot(welfare$birth)

table(is.na(welfare$birth))

# 이상치 결측 처리
welfare$birth <- ifelse(welfare$birth == 9999,NA,welfare$birth)
table(is.na(welfare$birth))

welfare$age <- 2015 - welfare$birth + 1
summary(welfare$age)

qplot(welfare$age)

# 나이에 따른 월급 평균표

table(is.na(welfare$income))

age_income <- welfare %>%
    filter(!is.na(income)) %>%
    group_by(age) %>%
    summarise(mean_income = mean(income))
head(age_income)
  
     
ggplot(data=age_income, aes(x = age, y=mean_income))  +
  geom_col()
  
ggplot(data=age_income, aes(x = age, y=mean_income))  +
  geom_line()

  
  
  
  

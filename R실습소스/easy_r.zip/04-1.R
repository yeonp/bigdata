# 04-1.R 
# 데이터프레임 실습

english <- c(90,80,60,70)
english

math <- c(50,60,100,20)
math

class <- c(1,1,2,2)
class

df_midterm <- data.frame(english,math,class)
df_midterm
View(df_midterm)
df_midterm$english
mean(df_midterm$english)
sum(df_midterm$english)
mean(df_midterm$math)


df_midterm <- data.frame(english=c(90,80,60,70),
                         math = c(50,60,100,20),
                         class = c(1,1,2,2) )
df_midterm
mean(df_midterm$english) # 평균 
sum(df_midterm$math)     # 합계 
min(df_midterm$english)  # 최소값
max(df_midterm$english)  # 최대값 
sd(df_midterm$english)  # 표준편차
summary(df_midterm)     # 모든 정보 요약

# 연습문제
sales <- data.frame(product=c("사과","딸기","수박"),
                    price = c(1800,1500,3000),
                    volume = c(24,38,13))
sales
mean(sales$price)
sum(sales$price)                    
mean(sales$volume)
sum(sales$volume)
min(sales$price)
max(sales$price)
sd(sales$price)
summary(sales)
str(sales)

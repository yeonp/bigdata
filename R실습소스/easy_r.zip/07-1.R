# 07-1.R

# 결측치 : NA(숫자), <NA>(문자)

df <- data.frame( sex=c("M","F",NA,"M","F"),
                 score=c(5,4,3,4,NA))
df

# 결측치 확인
df_is <- is.na(df)
df_is
table(df_is)

table(is.na(df$sex))
table(is.na(df$score))

mean(df$sex)
sum(df$score)
mean(df$score)

# 결측치 제거하기
library(dplyr)
    
df %>% filter(is.na(score))
df_nomiss <- df %>% filter(!is.na(score))
df_nomiss
mean(df_nomiss$score)
sum(df_nomiss$score)

df_nomiss <- df %>% filter(!is.na(score) & !is.na(sex))   # 해당 조건의 컬럼의 결측치만 제거 
df_nomiss

# na.omit() : 모든 컬럼의 결측치를 모두 제거 
df_nomiss <- na.omit(df)
df_nomiss

# 함수의 결측치 제외기능
mean(df$score, na.rm = T)
sum(df$score, na.rm = T) 

exam <- read.csv("csv_exam.csv")
exam[c(3,8,15),"math"] <- NA
exam

exam %>% summarise(mean_math=mean(math))
exam %>% summarise(mean_math=mean(math,na.rm = T))

exam %>% summarise(mean_math=mean(math,na.rm = T),
                   sum_math=sum(math,na.rm = T),
                   median_math = median(math,na.rm = T))

# 결측치를 평균값으로 대체하기

mean_math <- mean(exam$math,na.rm=T)  # 55.23529
mean_math

exam$math <- ifelse(is.na(exam$math),mean_math,exam$math)
exam
table(is.na(exam$math))

mean(exam$math)  # 55.2

# 문제 1
mpg[c(65, 124, 131, 153, 212), "hwy"] <- NA  # NA 할당하기

table(is.na(mpg$drv))  # drv 결측치 빈도표 출력

table(is.na(mpg$hwy))  # hwy 결측치 빈도표 출력

# 문제 2
mpg %>%
  filter(!is.na(hwy)) %>%          # 결측치 제외
  group_by(drv) %>%                # drv별 분리
  summarise(mean_hwy = mean(hwy))  # hwy      #summarise(mean_hwy = mean(hwy,na.rm=T))  # hwy 평균 구하기


# 이상치(Outlier) 제거 

outlier <- data.frame(sex=c(1,2,1,3,2,1),
                      score=c(5,4,3,4,2,6))
outlier

table(outlier$sex)
table(outlier$score)

# 이상치를 결측처리 
outlier$sex <- ifelse(outlier$sex > 2,NA,outlier$sex)

outlier$score <- ifelse(outlier$score > 5,NA,outlier$score)
outlier

# 결측치 처리 , 제거 
outlier %>%
  filter(!is.na(sex) & !is.na(score)) %>%
  group_by(sex) %>%
  summarise(mean_score = mean(score))

library(ggplot2)
ggplot(data= mpg,aes(x=drv,y=hwy)) + geom_boxplot()

boxplot(mpg$hwy)$out
mpg <- as.data.frame(ggplot2::mpg)  
quantile(mpg$hwy,na.rm=T)

# mpg의 극단치를 결측치로 제거 
mpg$hwy <- ifelse(mpg$hwy < 12 | mpg$hwy > 37, NA,mpg$hwy)
table(is.na(mpg$hwy))
View(mpg)

mpg %>%
  group_by(drv) %>%
  summarise(mean_hwy=mean(hwy,na.rm=T))

# 문제 1
mpg <- as.data.frame(ggplot2::mpg)
mpg[c(10, 14, 58, 93), "drv"] <- "k"                # drv 이상치 할당
mpg[c(29, 43, 129, 203), "cty"] <- c(3, 4, 39, 42)  # cty 이상치 할당

# 이상치 확인
table(mpg$drv)

# drv가 4, f, r이면 기존 값 유지, 그 외 NA할당
mpg$drv <- ifelse(mpg$drv %in% c("4", "f", "r"), mpg$drv, NA)

# 이상치 확인
table(mpg$drv)

# 문제 2
boxplot(mpg$cty)$stats
quantile(mpg$cty)

# 9~26 벗어나면 NA 할당
mpg$cty <- ifelse(mpg$cty < 9 | mpg$cty > 26, NA, mpg$cty)
# 상자 그림 생성
boxplot(mpg$cty)

# 문제 3
mpg %>%
  filter(!is.na(drv) & !is.na(cty)) %>%  # 결측치 제외
  group_by(drv) %>%                      # drv별 분리
  summarise(mean_hwy = mean(cty))        # cty 평균 구하기

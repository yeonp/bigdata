a <- 1
b <- 2
c <- a + b
c

add <- function(a,b)
{
  c <- a + b
  return(c)
}

result <- add(50,20)
print(result)
result <- add(-100,40) 
print(result)

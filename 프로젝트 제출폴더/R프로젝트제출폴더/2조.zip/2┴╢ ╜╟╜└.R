install.packages("foreign")
library(foreign)
library(dplyr)
library(ggplot2)
library(readxl)


df_edu<-read.csv(file="범죄자교육정도_2016년_.csv",stringsAsFactor=F)
df_edu

var1<-as.numeric(df_edu$초등학교.재중.)
var1

var2<-as.numeric(df_edu$초등학교.중퇴.)
var2

var3<-as.numeric(df_edu$초등학교.졸업.)
var3

edu_0<-df_edu %>% mutate(ele= var1 + var2 + var3)
edu_0
df_E<-edu_0 %>% filter(범죄대분류=="지능범죄")%>%select(ele)
df_E







var4<-as.numeric(df_edu$중학교.재중.)
var4
var5<-as.numeric(df_edu$중학교.중퇴.)
var5
var6<-as.numeric(df_edu$중학교.졸업.)
var6
edu_A<-df_edu %>% mutate(mid= var4 + var5+ var6)
edu_A
df_M<-edu_A %>% filter(범죄대분류=="지능범죄")%>%select(mid)
df_M




var7<-as.numeric(df_edu$고등학교.재중.)
var7
var8<-as.numeric(df_edu$고등학교.중퇴.)
var8
var9<-as.numeric(df_edu$고등학교.졸업.)
var9
edu_B<-df_edu %>% mutate(hig= var7 + var8+ var9)
edu_B
df_H<-edu_B %>% filter(범죄대분류=="지능범죄")%>%select(hig)
df_H



varA<-as.numeric(df_edu$대학.4년미만..재중.)
varA
varB<-as.numeric(df_edu$대학.4년미만..중퇴.)
varB
varC<-as.numeric(df_edu$대학.4년미만..졸업.)
varC
edu_C<-df_edu %>% mutate(uni123 = varA + varB+ varC)
edu_C
df_U<-edu_C %>% filter(범죄대분류=="지능범죄")%>%select(uni123)
df_U






varD<-as.numeric(df_edu$대학.4년이상..재중.)
varD
varE<-as.numeric(df_edu$대학.4년이상..중퇴.)
varE
varF<-as.numeric(df_edu$대학.4년이상..졸업.)
varF
edu_D<-df_edu %>% mutate(uni4 = varD + varE+ varF)
edu_D
df_U1<-edu_D %>% filter(범죄대분류=="지능범죄")%>%select(uni4)
df_U1

vara<-as.numeric(df_edu$대학원.재중.)
vara
varb<-as.numeric(df_edu$대학원.중퇴.)
varb
varc<-as.numeric(df_edu$대학원.졸업.)
varc

edu_E<-df_edu %>% mutate(gra = vara + varb+ varc)
edu_E
df_G<-edu_E %>% filter(범죄대분류=="지능범죄")%>%select(gra)
df_G


                    


df_edu$불취학<-as.numeric(df_edu$불취학)

df_B<-df_edu %>% filter(범죄대분류=="지능범죄")%>%select(범죄중분류,불취학)

df_edu$기타<-as.numeric(df_edu$기타)
df_gi<-df_edu %>% filter(범죄대분류=="지능범죄")%>%select(기타)

df_edu$미상<-as.numeric(df_edu$미상)
df_mi<-df_edu %>% filter(범죄대분류=="지능범죄")%>%select(미상)


class<-df_edu%>%filter(범죄대분류=="지능범죄")%>%group_by(범죄중분류)
class



level<-data.frame(level= c("불취학",
                                "ele",
                                "mid",
                                "hig",
                                "uni123",
                                "uni4",
                                "gra",
                                "기타",
                                "미상"))

level







#ages
education <- data.frame(df_B,
                    df_E,
                    df_M,
                    df_H,
                    df_U,
                    df_U1,
                    df_G,
                    df_gi,
                    df_mi
                    )
  education

education[is.na(education)] <- 0
education

x<-cbind(education,level)
x

  



ggplot(data=x ,aes(x=level, y=범죄중분류)) + geom_col()
  
                    
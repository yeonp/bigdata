library(ggplot2)
library(dplyr)
library(gridExtra)

car_acc<-read.csv("C:/Users/CPB06GameN/Desktop/PROGRAM/R/data/도로교통공단_전국_사망교통사고정보_2018_.csv")

dim(car_acc)
str(car_acc)

nd<-car_acc %>% group_by(주야) %>% summarise(n=n())
nd
car_acc %>% filter(사고유형_대분류=='차대사람') %>% group_by(주야) %>% summarise(n=n())

car_acc %>% filter(사고유형_대분류=='차대차') %>% group_by(주야) %>% summarise(n=n())

levels(car_acc$사고유형_중분류)
levels(car_acc$사고유형)


car_acc %>% filter(사고유형=='횡단중') %>% group_by(주야) %>% summarise(n=n())


car_acc$week<-ifelse(car_acc$요일 %in% c('토','일'),'주말','평일')
table(car_acc$week)

car_acc_injury<-car_acc %>% mutate(injury = 사망자수+사상자수+중상자수+경상자수)

car_acc_injury %>%  group_by(week) %>% summarise(mean=mean(injury))
nd_injury<-car_acc_injury %>% filter(사고유형_대분류=='차대사람') %>%  group_by(요일, 사망자수) %>% summarise(n=n())
nd_injury

ggplot(nd_injury, mapping=aes(x=사망자수 , color=요일))+ geom_freqpoly(binwidth = 0.5)

#############################################################################

nd<-car_acc %>% group_by(주야) %>% summarise('빈도'=n())


#########여기에서 요일을 모두 주야 로 돌리면 주야 그래프가 나옵니다.
aa1<-car_acc %>% filter(사고유형_대분류=='차대사람') %>% group_by(요일) %>% summarise('빈도'=n())

aa2<-car_acc %>% filter(사고유형_대분류=='차대차') %>% group_by(요일) %>% summarise('빈도'=n())

acc_big<-car_acc %>% filter(사고유형_대분류=='차대사람') %>%   group_by(요일, 사고유형_중분류) %>% summarise('빈도'=n())


week<-car_acc %>% group_by(요일, 주야) %>% summarise('빈도'=n())

week

ggplot(nd, mapping=aes(x=주야 , y=빈도),fill='blue')+ geom_col()

ggplot(week, mapping=aes(x=요일 , y=빈도, fill=주야))+ geom_col(position = 'dodge')

ggplot(aa1, mapping=aes(x=요일 , y=빈도))+ geom_col()

ggplot(aa2, mapping=aes(x=요일 , y=빈도))+ geom_col(position = 'dodge')

ggplot(acc_big, mapping=aes(x=사고유형_중분류 , y=빈도,fill=요일))+ geom_col(position = 'dodge')





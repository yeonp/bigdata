library(foreign)
library(dplyr)
library(ggplot2)
library(readxl)
library(kormaps2014)
library(ggiraphExtra)
library(stringi)
install.packages("ggiraphExtra")
install.packages("stringi")
install.packages("devtools")
install.packages("mapproj")
devtools::install_github("cardiomoon/kormaps2014")
force=TRUE
#지역별 교통사고 발생 평균
df_csv <- read.csv("도로교통공단_시도_시군구별_사고유형별_교통사고(2018).csv")
df_new <- df_csv
str(df_new)
df_new <- rename(df_new,region=시도,accident=발생건수)
df_new %>% select(region,accident) 
region_accident <-df_new %>% group_by(region) %>%
  summarise(mean_accident = round(mean(accident),0))



region_accident$code<-c(32,31,38,37,24,22,25,21,11,29,26,23,36,35,39,34,33)
region_accident
str(changeCode(region_accident))

##### 전국 사고율 표 ###
ggplot(region_accident, aes(x=region, y=mean_accident)) + geom_col()      
as.character("region_accident")    
class("region_accident")

#지역별 교통사고 사망률
df_new_d<-df_csv
str(df_new_d)
df_new_d <-df_new_d %>%  select("시도","사망자수")
df_new_d <-rename(df_new_d,region="시도",death="사망자수")

df_new_d %>% head
region_death <-df_new_d %>% group_by(region) %>%
  summarise(mean_death = (mean(death)))

region_death$code <-c(32,31,38,37,24,22,25,21,11,29,26,23,36,35,39,34,33)
region_death
str(changeCode(region_death))
ggplot(region_death, aes(x=region, y=mean_death )) + geom_col()      

#단계구분도

library(tibble)
region_accident
options(encoding="UTF-8")



as.character(region_accident)

ggChoropleth(data = region_accident,
            aes(fill = mean_accident, 
            map_id = code,
            tooltip = kormap1),
            map = kormap1,
            interactive = T)
            
            
ggChoropleth(data = region_death,
             aes(fill = mean_death, 
                 map_id = code,
                 tooltip = kormap1),
             map = kormap1,
             interactive = T)

    



View(region_accident)
str(region_accident)


as.character(tbc)
as.character(region_death)
str(region_accident)
str(region_death)



import random
class updown: # 작성자 : 연지혜
    def __init__(self):
        self.rn = random.randint(1,100)
        self.num = -1
        self.t_cnt = 0 # 시도횟수
        self.score = 0 # 점수
        self.name = ' '

    def play(self):  # 게임 실행

        print("1~100 숫자 Up & Down 게임을 시작합니다 !!!")
        print("---------------------------")
        self.name = input('이름을 입력하세요  :')
        while ( self.rn != self.num ): # 정답 시 while문 종료

            self.num = int(input("1 ~ 100 사이의 숫자를 입력하세요 : "))

            if (self.num > self.rn):
                print("Down")
            elif (self.num < self.rn):
                print("Up")
            elif (self.num > 100):
                print("100 보다 작은 수를 입력해 주세요") # 숫자 크기에 따른 up & down 정보 제공

            self.t_cnt += 1 # 시도 횟수 증가

        print("--------------------------------")
        print(self.t_cnt, "번 만에 정답을 맞추셨습니당~~'_'")
        self.score =self.score + (100 - self.t_cnt)
        print(self.name,'님',self.score, '점 획득!') # name과 score 출력

        return self.name,self.score

    def save_score(self):   # 게임결과 저장
        f = open('Score.csv','a',encoding= 'utf-8')
        f.write(self.name + ', ')
        f.write(str(self.score))
        f.write('\n')
        f.close()
import random
import time

class yougame(): # 작성자 : 정인철
    def __init__(self):
        self.x = 0
        self.y = 0
        self.dict = {-1:'빽도', 1:'도' , 2:'개', 3:'걸', 4:'윷', 5:'모'}
        self.mine = []
        self.num = 7
        self.str = ""
        self.score = 0
        self.name = ' '
        self.game_time= 0
        self.mine_location = random.randint(0, self.num * self.num - 1)
        self.game_time_start = time.time()
        self.m_point = [-1, 1, 2, 3, 4, 5]
        self.m_list = [42, 43, 44, 45, 46, 47, 48, 41, 34, 27, 20, 13, 6, 5, 4, 3, 2, 1, 0, 7, 14, 21, 28, 35]
        self.m2_list = [42, 43, 44, 45, 46, 47, 48, 40, 32, 24, 16, 8, 0, 7, 14, 21, 28, 35]
        self.m22_list = [42, 43, 44, 45, 46, 47, 48, 40, 32, 24, 30, 36]
        self.m3_list = [42, 43, 44, 45, 46, 47, 48, 41, 34, 27, 20, 13, 6, 12, 18, 24, 30, 36]
        self.m33_list = [42, 43, 44, 45, 46, 47, 48, 41, 34, 27, 20, 13, 6, 12, 18, 24, 32, 40, 48, 41, 34, 27, 20, 13, 6, 5, 4, 3, 2, 1, 0, 7, 14, 21, 28, 35]
        self.sum = 0
        self.sum2 = 0
        self.count = 0
        self.k = 42
        self.k2 = 42
        self.game_time= 0
        self.game_time_start = time.time()
        self.score = 0
        print('score :',self.score, '  game_time:', self.game_time)
        print('data_frame : ', self.num, 'X', self.num)

        for i in range(0, self.num * self.num):
            if i == 0:
                self.mine.append("*")
            elif i == 1 :
                self.mine.append("*")
            elif i == 2 :
                self.mine.append("*")
            elif i == 3 :
                self.mine.append("*")
            elif i == 4 :
                self.mine.append("*")
            elif i == 5 :
                self.mine.append("*")
            elif i == 6 :
                self.mine.append("*")
            elif i == 7 :
                self.mine.append("*")
            elif i == 8 :
                self.mine.append("*")
            elif i == 12 :
                self.mine.append("*")
            elif i == 13 :
                self.mine.append("*")
            elif i == 14:
                self.mine.append("*")
            elif i == 16:
                self.mine.append("*")
            elif i == 18:
                self.mine.append("*")
            elif i == 20:
                self.mine.append("*")
            elif i == 21:
                self.mine.append("*")
            elif i == 24:
                self.mine.append("*")
            elif i == 27:
                self.mine.append("*")
            elif i == 28:
                self.mine.append("*")
            elif i == 30:
                self.mine.append("*")
            elif i == 32:
                self.mine.append("*")
            elif i == 34 :
                self.mine.append("*")
            elif i == 35 :
                self.mine.append("*")
            elif i == 36 :
                self.mine.append("*")
            elif i == 40 :
                self.mine.append("*")
            elif i == 41 :
                self.mine.append("*")
            elif i == 42 :
                self.mine.append("X")
            elif i == 43 :
                self.mine.append("*")
            elif i == 44 :
                self.mine.append("*")
            elif i == 45 :
                self.mine.append("*")
            elif i == 46 :
                self.mine.append("*")
            elif i == 47 :
                self.mine.append("*")
            elif i == 48 :
                self.mine.append("*")
            else :
                self.mine.append(" ")

        for i in range(len(self.mine)):
            if (i + 1) % self.num is 0:
                self.str += self.mine[i][0] + " \n"
            else:
                self.str += self.mine[i][0] + " "
        print(self.str)

    def mine_print(self):
        mine_str = ""
        for i in range(len(self.mine)):
            if (i + 1) % self.num is 0:
                mine_str += self.mine[i][0] + " \n"
            else:
                mine_str += self.mine[i][0] + " "
        print(self.count, '회차', '   유저이동(X):',self.dict[self.x], self.x, '   상대이동(O):', self.dict[self.y],self.y)
        print(mine_str)


    def table(self):
        self.name = input("이름을 입력하세요 : ")
        try:
            self.mine[42] = "*"
            while True:
                self.mine[self.k2] = "*"
                self.mine[self.k] = "*"

                var1 = input("실행하시겠습니까? y/n:")

                if var1 == 'y':
                    self.x = random.choice(self.m_point)
                    self.y = random.choice(self.m_point)
                    self.sum = int(self.x + self.sum)
                    self.sum2 = int(self.y + self.sum2)

                    if self.sum == 6:
                        k = self.m2_list[self.sum]
                        k2 = self.m_list[self.sum2]
                        self.k = k
                        self.k2 = k2
                        self.mine[k2] = "O"
                        self.mine[k] = "X"
                        self.count = 1 + self.count
                        self.mine_print()

                        while True:
                            self.mine[self.k2] = "*"
                            self.mine[self.k] = "*"
                            var1 = input("실행하시겠습니까? y/n:")
                            if var1 == 'y':
                                self.x = random.choice(self.m_point)
                                self.y = random.choice(self.m_point)
                                self.sum = int(self.x + self.sum)
                                self.sum2 = int(self.y + self.sum2)
                                if self.sum == 9:
                                    k = self.m22_list[self.sum]
                                    k2 = self.m_list[self.sum2]
                                    self.k = k
                                    self.k2 = k2
                                    self.mine[k2] = "O"
                                    self.mine[k] = "X"
                                    self.count = 1 + self.count
                                    self.mine_print()

                                    while True:
                                        self.mine[self.k2] = "*"
                                        self.mine[self.k] = "*"
                                        var1 = input("실행하시겠습니까? y/n:")
                                        if var1 == 'y':
                                            self.x = random.choice(self.m_point)
                                            self.y = random.choice(self.m_point)
                                            self.sum = int(self.x + self.sum)
                                            self.sum2 = int(self.y + self.sum2)
                                            k = self.m22_list[self.sum]
                                            k2 = self.m_list[self.sum2]
                                            self.k = k
                                            self.k2 = k2
                                            self.mine[k2] = "O"
                                            self.mine[k] = "X"
                                            self.count = 1 + self.count
                                            self.mine_print()

                                        elif var1 == 'n':
                                            print('게임이 끝났습니다.')
                                            return
                                        else :
                                            print('다시 실행하세요!')

                                else:
                                    k = self.m2_list[self.sum]
                                    k2 = self.m_list[self.sum2]
                                    self.k = k
                                    self.k2 = k2
                                    self.mine[k2] = "O"
                                    self.mine[k] = "X"
                                    self.count = 1 + self.count
                                    self.mine_print()

                            elif var1 == 'n':
                                print('게임이 끝났습니다.')
                                return
                            else:
                                print('다시 실행하세요!')

                    if self.sum == 12:
                        k = self.m3_list[self.sum]
                        k2 = self.m_list[self.sum2]
                        self.k = k
                        self.k2 = k2
                        self.mine[k2] = "O"
                        self.mine[k] = "X"
                        self.count = 1 + self.count
                        self.mine_print()

                        while True:
                            self.mine[self.k2] = "*"
                            self.mine[self.k] = "*"
                            var1 = input("실행하시겠습니까? y/n:")
                            if var1 == 'y':
                                self.x = random.choice(self.m_point)
                                self.y = random.choice(self.m_point)
                                self.sum = int(self.x + self.sum)
                                self.sum2 = int(self.y + self.sum2)

                                if self.sum == 15:
                                    k = self.m33_list[self.sum]
                                    k2 = self.m_list[self.sum2]
                                    self.k = k
                                    self.k2 = k2
                                    self.mine[k2] = "O"
                                    self.mine[k] = "X"
                                    self.count = 1 + self.count
                                    self.mine_print()

                                    while True:
                                        self.mine[self.k] = "*"
                                        self.mine[self.k2] = "*"
                                        var1 = input("실행하시겠습니까? y/n:")
                                        if var1 == 'y':
                                            self.x = random.choice(self.m_point)
                                            self.y = random.choice(self.m_point)
                                            self.sum = int(self.x + self.sum)
                                            self.sum2 = int(self.y + self.sum2)
                                            k = self.m33_list[self.sum]
                                            k2 = self.m_list[self.sum2]
                                            self.k = k
                                            self.k2 = k2
                                            self.mine[k2] = "O"
                                            self.mine[k] = "X"
                                            self.count = 1 + self.count
                                            self.mine_print()
                                        elif var1 == 'n':
                                            print('게임이 끝났습니다.')
                                            return
                                        else:
                                            print('다시 실행하세요!')
                                else:
                                    k = self.m3_list[self.sum]
                                    k2 = self.m_list[self.sum2]
                                    self.k = k
                                    self.k2 = k2
                                    self.mine[k2] = "O"
                                    self.mine[k] = "X"
                                    self.count = 1 + self.count
                                    self.mine_print()

                            elif var1 == 'n':
                                print('게임이 끝났습니다.')
                                return
                            else:
                                print('다시 실행하세요!')

                    else :
                        k = self.m_list[self.sum]
                        k2 = self.m_list[self.sum2]
                        self.k = k
                        self.k2 = k2
                        self.mine[k2] = "O"
                        self.mine[k] = "X"
                        self.count = 1 + self.count
                        self.mine_print()
                elif var1 == 'n':
                    print('게임이 끝났습니다.')
                    return

                else :
                    print('다시 입력하십시오!')

        except IndexError:
            if self.sum > self.sum2 :
                print("게임에서 이겼습니다.")
                self.score = 100
            else :
                print("게임에서 졌습니다.")
                self.score = 0

            self.mine[42] = "X"
            self.count = 1 + self.count
            game_time_end = time.time()
            self.game_time = round(game_time_end - self.game_time_start)
            print('총', self.count, '회 실시함.','    총 score :', self.score, '    총시간 :', self.game_time, '초')
            print('=================================================')
            self.mine_print()

        f = open('score.csv', 'a', encoding='utf-8')
        f.write(self.name + ', ')
        f.write(str(self.score) + '\n')
        f.close()  #게임 결과저장

if __name__ == '__main__':
    test = yougame()
    test.table()


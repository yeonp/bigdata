# 파이썬 프로젝트 요구사항
class data_frame:
    def __init__(self):
        self.count = 0
        self.var1 = 0
        self.var2 = 0
        self.data_list2 = []


    def print(self, name):
        print('내용을 출력한다.')
        f = open('{0}.txt'.format(name), 'r', encoding='UTF-8')
        lines = f.readlines()
        for line in lines:
            print(line, end='')
        print('\n')
        f.close()



    def var(self, name):
        print('변수속성을 출력한다.')
        f = open('{0}.txt'.format(name), 'r', encoding='UTF-8')
        print(f)
        header = f.readline()
        header_list = header.split()
        a = []
        data_list = []
        for x in range(0,len(header_list)):
            line = []
            a.append(line)

        while True:
            line = f.readline()
            self.count = 1 + self.count
            if not line: break
            row = line.split()
            data_list.append(row)
            for x in range(0, len(header_list)):
                a[x].append(row[x])

        print(self.count, 'obs. of', len(header_list), 'variables:')
        for x in range(0,len(header_list)):
            print(header_list[x], ':', type(header_list[x]),a[x])
        print('\n')
        f.close()




    def var_count(self, name):
        print('변수의 수와 데이터를 출력한다.')
        f = open('{0}.txt'.format(name), 'r', encoding='UTF-8')
        header = f.readline()
        header_list = header.split()
        print('변수의 수:', len(header_list))

        lines = f.readlines()
        for line in lines:
            print(line, end='')
        print('\n')
        f.close()



    def name_list(self, name):
        print('변수항목을 리스트로 만든다')
        f = open('{0}.txt'.format(name), 'r', encoding='UTF-8')
        header = f.readline()
        header_list = header.split()
        print(header_list)
        print('\n')
        f.close()



    def head5(self,name):
        print("앞부터 5번째까지 출력, 그 이하면 모두 출력됨")
        f = open('{0}.txt'.format(name), 'r', encoding='UTF-8')
        lines = f.readlines()

        if self.count >= 5 :
            for x in range(0,5):
                print(lines[x], end='')
            print('\n')
        else :
            for x in range(0, self.count):
                print(lines[x], end='')
            print('\n')
        f.close()


    def tail5(self,name):
        print("뒤부터 5번째까지 출력, 그 이하면 모두 출력됨")
        f = open('{0}.txt'.format(name), 'r', encoding='UTF-8')
        lines = f.readlines()

        if self.count >= 5 :
            print(lines[self.count - 1])
            for x in range(0,4):
                y = self.count-x
                print(lines[y-2], end='')
        else :
            print(lines[self.count - 1])
            for x in range(0, self.count-1):
                y = self.count - x
                print(lines[y - 2], end='')
        print('\n')
        f.close()


    def rename(self, name, num, var2):
        print('변수이름을 변경하는 기능을 제공한다.')
        f = open('{0}.txt'.format(name), 'r', encoding='UTF-8')
        header = f.readline()
        header_list = header.split()
        header_list[num-1] = var2
        var1 = str(header_list)
        print(var1)
        lines = f.readlines()
        for line in lines:
            print(line, end='')

        f = open('{0}11.txt'.format(name), 'w', encoding='UTF-8')

        for x in range(len(header_list)-1):
            f.write(header_list[x] +'      ')
        f.write(header_list[len(header_list)-1])
        f.write('\n')

        for line in lines:
            f.write(line)
        print('\n')
        f.close()



    def m_plus(self, name, headername, data):
        print('파생변수를 추가하는 기능을 제공한다')
        f = open('{0}.txt'.format(name), 'r', encoding='UTF-8')
        # 파생변수 이름 추가
        header = f.readline()
        header_list = header.split()
        header_list.append(headername)

        # 데이터 열로 추가하기
        data_list = []
        while True:
            line = f.readline()
            if not line: break
            row = line.split()
            data_list.append(row)
        for x in range(0, self.count-1):
            data_list[x].append(data[x])
        f.close()

        # 파일 재작성 및 변수 추가
        f = open('{0}11.txt'.format(name), 'w', encoding='UTF-8')
        for x in range(len(header_list)):
            f.write(header_list[x] +' ')

        for x in range(self.count-1):
            f.write('\n')
            for k in range(len(header_list)):
                f.write(str(data_list[x][k]) + '      ')
        f.close()


    def var_select(self, name, var_name):
        print('필요한 변수를 추출하는 기능을 제공한다')
        f = open('{0}.txt'.format(name), 'r', encoding='UTF-8')
        header = f.readline()
        header_list = header.split()

        for x in range(len(header_list)):
            if header_list[x] == var_name:
                print(header_list[x])
                self.var1 = x

        # 해당변수의 데이터 출력하기
        while True:
            line = f.readline()
            data_list = line.split()
            if not line: break
            print(data_list[self.var1])
        print('\n')
        f.close()


    def var_filter(self, name, var_name, ifname, num):
        print('조건에 따른 데이터를 추출한다')
        f = open('{0}.txt'.format(name), 'r', encoding='UTF-8')
        header = f.readline()
        header_list = header.split()
        for x in range(len(header_list)):
            print(header_list[x], end='  ')

        for x in range(len(header_list)):
            if header_list[x] == var_name:
                self.var2 = x

        data_list = []


        while True:
            line = f.readline()
            if not line: break
            row = line.split()
            data_list.append(row)


        if ifname == '==':
            print()
            for x in range(0, self.count-1):
                for k in range(0, len(header_list)):
                    if num == float(data_list[x][self.var2]):
                        print(data_list[x][k], end='        ')

        if ifname == '!=':
            print()
            for x in range(0, self.count-1):
                for k in range(0, len(header_list)):
                    if num != float(data_list[x][self.var2]):
                        print(data_list[x][k], end='        ')
                print()

        if ifname == '<=':
            print()
            for x in range(0, self.count-1):
                for k in range(0, len(header_list)):
                    if num >= float(data_list[x][self.var2]):
                        print(data_list[x][k], end='        ')
                print()

        if ifname == '>=':
            print()
            for x in range(0, self.count-1):
                for k in range(0, len(header_list)):
                    if num <= float(data_list[x][self.var2]):
                        print(data_list[x][k], end='        ')
                print()
        f.close()

    def var_arrange(self, name, var_name, how):
        print('정렬기능을 제공한다. 오름/내림차순')
        f = open('{0}.txt'.format(name), 'r', encoding='UTF-8')
        header = f.readline()
        header_list = header.split()
        for x in range(len(header_list)):
            print(header_list[x], end='  ')
            if header_list[x] == var_name:
                self.var2 = x

        data_list = []
        while True:
            line = f.readline()
            if not line: break
            row = line.split()
            data_list.append(row)

        a = []
        if how == 'aec':
            for x in range(0, self.count-1):
                a.append(int(data_list[x][self.var2]))
            a1 = sorted(a)

            for x in range(0, len(a1)):
                for k in range(0, self.count-1):
                    if float(a1[x]) == float(data_list[k][self.var2]):
                        print()
                        for y in range(0, len(header_list)):
                            print(data_list[k][y], end='        ')

        elif how == 'dec':
            for x in range(0, self.count-1):
                a.append(int(data_list[x][self.var2]))
            a1 = sorted(a, reverse=True)

            for x in range(0, len(a1)):
                for k in range(0, self.count-1):
                    if float(a1[x]) == float(data_list[k][self.var2]):
                        print()
                        for y in range(0, len(header_list)):
                            print(data_list[k][y], end='        ')
        else :
            print()
            print('잘못입력하셨습니다.')
        print('\n')
        f.close()

    def var_preview(self, name):
        print('데이터요약기능을 제공한다.')
        f = open('{0}.txt'.format(name), 'r', encoding='UTF-8')
        header = f.readline()
        header_list = header.split()
        a = []
        data_list = []
        for x in range(0, len(header_list)):
            line = []
            a.append(line)
        while True:
            line = f.readline()
            if not line: break
            row = line.split()
            data_list.append(row)
            for x in range(0, len(header_list)):
                a[x].append(float(row[x]))

        for x in range(0, len(header_list)):
            print(header_list[x], ':', '최소값', min(a[x]), '최대값', max(a[x]),'합계', sum(a[x]), '평균', (sum(a[x])/len(a[x])))
        print('\n')
        f.close()

    def count_n(self, name):
        print('빈도분석 기능을 제공한다.')
        f = open('{0}.txt'.format(name), 'r', encoding='UTF-8')
        header = f.readline()
        header_list = header.split()

        data_list = []
        namelist = []

        while True:
            line = f.readline()
            if not line: break
            row = line.split()
            data_list.append(row)
        for x in range(self.count-1):
            for y in range(0, len(header_list)):
                namelist.append(data_list[x][y])
        namelist = list(set(namelist))

        for x in range(0, len(namelist)):
            count = 0
            for y in range(self.count - 1):
                for z in range(0, len(header_list)):
                    if namelist[x] == data_list[y][z]:
                        count = count + 1
            print(namelist[x], ':', count)
        f.close()

    def var_sum(self, name, var_name):
        print('합계를 계산하는 기능을 제공한다.')
        f = open('{0}.txt'.format(name), 'r', encoding='UTF-8')
        header = f.readline()
        header_list = header.split()
        a = []
        data_list = []
        for x in range(0, len(header_list)):
            line = []
            a.append(line)
        while True:
            line = f.readline()
            if not line: break
            row = line.split()
            data_list.append(row)
            for x in range(0, len(header_list)):
                a[x].append(float(row[x]))

        for x in range(len(header_list)):
            if header_list[x] == var_name:
                self.var2 = x

        print(header_list[self.var2],': 합계', sum(a[self.var2]))
        print('\n')
        f.close()

    def group_sum(self, name, group, var1):
        print('그룹별 합계를 계산하는 기능을 제공한다.')
        f = open('{0}.txt'.format(name), 'r', encoding='UTF-8')
        header = f.readline()
        header_list = header.split()
        for x in range(len(header_list)):
            if header_list[x] == group:
                self.var2 = x

        for x in range(len(header_list)):
            if header_list[x] == var1:
                self.var3 = x

        print(header_list[self.var2],',', header_list[self.var3])


        data_list = []
        namelist = []

        while True:
            line = f.readline()
            if not line: break
            row = line.split()
            data_list.append(row)
        for x in range(self.count-1):
            namelist.append(data_list[x][self.var2])
        namelist = list(set(namelist))
        for x in range(0, len(namelist)):
            sum = 0
            for y in range(self.count - 1):
                if namelist[x] == data_list[y][self.var2]:
                    sum = int(data_list[y][self.var3]) + sum
            print(namelist[x], '          ', sum)
        f.close()
        print()

    def data_join(self, name, var_list):
        print('data를 추가로 결합합니다.')
        f = open('{0}.txt'.format(name), 'r', encoding='UTF-8')
        header = f.readline()
        header_list = header.split()
        var1 = len(header_list)
        f.close()

        f = open('{0}.txt'.format(name), 'a', encoding='UTF-8')
        if len(var_list) > var1:
            for x in range(0, len(var_list)):
                if x % var1 == 0:
                    f.write('\n')
                f.write(str(var_list[x]) + '           ')
        else :
            for x in range(0, len(var_list)):
                f.write(str(var_list[x]) + '           ')
        f.close()
        print()


    def var_join(self, name, var1, name2):
        print('변수결합 기능을 제공한다.')
        # 테이블의 헤더 읽기
        f = open('{0}.txt'.format(name), 'r', encoding='UTF-8')
        header = f.readline()
        header_list = header.split()

        # 테이블1의 헤더 중 var1과 일치하는 헤더있는지 확인
        for x in range(len(header_list)):
            if header_list[x] == var1:
                # 일치하는 헤더가 있으면 테이블2의 헤더를 테이블1의 결합, var1에 해당하는 테이블2의 헤더는 결합 안함
                f2 = open('{0}.txt'.format(name2), 'r', encoding='UTF-8')
                header2 = f2.readline()
                self.header_list2 = header2.split()

                for x in range(len(self.header_list2)):
                    if self.header_list2[x] == var1:
                        self.var2 = x

                for x in range(len(self.header_list2)):
                    if var1 != self.header_list2[x]:
                     header_list.append(self.header_list2[x])

                self.count = 0
                self.data_list2 = []
                while True:
                    line = f2.readline()
                    self.count = 1 + self.count
                    if not line: break
                    row = line.split()
                    self.data_list2.append(row)
                f2.close()

        # 헤더결합 확인

        # 테이블 2의 데이터를 테이블 1의 테이블에 결합, var1의 데이터는 결합하지 않음
        self.count = 0
        data_list = []
        while True:
            line = f.readline()
            self.count = 1 + self.count
            if not line: break
            row = line.split()
            data_list.append(row)
        for x in range(0, self.count - 1):
            for y in range(0, len(self.header_list2)):
                if self.var2 != y:
                    data_list[x].append(self.data_list2[x][y])

        # 데이터 결합 확인

        # 테이블 생성 및 테이블1과 테이블2의 종합 헤더와 데이터 쓰기
        for x in range(len(header_list)):
            if header_list[x] == var1:
                f = open('{0}11.txt'.format(name), 'w', encoding='UTF-8')
                for x in range(len(header_list)):
                    f.write(str(header_list[x]) + ' ')

                for x in range(self.count - 1):
                    f.write('\n')
                    for k in range(len(header_list)):
                        f.write(str(data_list[x][k]) + '      ')
                f.close()

        f = open('{0}11.txt'.format(name), 'r', encoding='UTF-8')
        lines = f.readlines()  # 모든 줄을 다 읽고 리스트로 반환함
        for line in lines:
            print(line, end='')
        print('\n')


    def staringe_num(self, name):
        print('이상치 처리 기능을 제공한다(대체, 제거)')
        num = input('원하는 이상치 int를 입력하시오:')
        var1 = input('원하는 이상치의 그 이상을 대체하고 싶으면 "이상"입력, 그 이하를 대체하고 싶으면 "이하"입력:')
        var2 = input('대처하고 싶은값을 입력하시오, 제거하고 싶으면 "제거"입력:')

        # 테이블의 헤더 읽기
        f = open('{0}.txt'.format(name), 'r', encoding='UTF-8')
        header = f.readline()
        header_list = header.split()
        for x in range(0, len(header_list)):
           print(header_list[x], end='   ')


        # 테이블의 데이터 읽기
        data_list = []
        self.count = 0
        while True:
            line = f.readline()
            self.count = 1 + self.count
            if not line: break
            row = line.split()
            data_list.append(row)

        # 이상치 조건
        if var1 == '이상':
            for x in range(0, self.count-1):
                print()
                for y in range(0, len(header_list)):
                    if var2 == '제거':
                        if float(num) <= float(data_list[x][y]):
                            print('   ', end='        ')
                        else:
                            print(data_list[x][y], end='        ')
                    else:
                        if float(num) <= float(data_list[x][y]):
                            print(var2, end='        ')
                        else:
                            print(data_list[x][y], end='        ')

        else :
            for x in range(0, self.count-1):
                print()
                for y in range(0, len(header_list)):
                    if var2 == '제거':
                        if float(num) >= float(data_list[x][y]):
                            print('   ', end='        ')
                        else:
                            print(data_list[x][y], end='        ')
                    else:
                        if float(num) >= float(data_list[x][y]):
                            print(var2, end='        ')
                        else:
                            print(data_list[x][y], end='        ')

    def graph(self, name):
        print('막대그래프를 출력한다')
        f = open('{0}.txt'.format(name), 'r', encoding='UTF-8')
        header = f.readline()
        header_list = header.split()

        # 데이터 파일 읽기
        data_list = []
        self.count = 0
        while True:
            line = f.readline()
            self.count = 1 + self.count
            if not line: break
            row = line.split()
            data_list.append(row)

        sum = []
        var = []
        for x in range(0, self.count-1 ):
            sum_int = 0
            for y in range(1, len(header_list)):
                sum_int = int(data_list[x][y]) + sum_int
            sum.append(sum_int)

        for x in range(0, len(sum)):
            var.append(round(sum[x] / 5))

        for x in range(0, len(sum)):
            print('   ')
            print('{0}'.format(' '*len(data_list[x][0])), '*' * round(sum[x]/5))
            print(data_list[x][0], ' ' * (round(sum[x]/5)-2), '*', sum[x], '점')
            print('{0}'.format(' '*len(data_list[x][0])), '*' * round(sum[x]/5))
        max_var = (int(max(sum))//10)

        print('{0}'.format(' '*len(data_list[0][0])), 0, '-' * (round(max(sum)/5)-3), max_var*10)






if __name__ == '__main__':
    k =data_frame()
    k.graph('Score')

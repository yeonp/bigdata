import os
class Manage:
    def addStu(self):#add student
        self.cnt = 0
        print("학생을 추가합니다.")
        self.name = input("name : ")
        stList = open("student.txt","r",encoding="UTF-8")
        while True:
            line = stList.readline()
            if not line:break
            if line[0:-1] ==self.name:
                self.cnt = 1
        stList.close()

        if self.cnt == 1:
            print("같은 이름이 있습니다. 다른 이름을 입력해주세요.")
            input("enter를 누르면 다음 화면으로 이동합니다.")
        else:
            print("학생을 생성합니다.")
            st = open(self.name+".txt","w",encoding="UTF-8")
            st.write("년 월 일 요일 입실시간 퇴실시간 수강시간\n")
            st.close()
            st2 = open("student.txt","a",encoding="UTF-8")
            st2.write(self.name+"\n")
            st2.close()
            input("enter를 누르면 다음 화면으로 이동합니다.")

    def searchStu(self):
        print("학생을 검색합니다.")
        name = input("name : ")
        f = open("student.txt","r",encoding="UTF-8")
        while True:
            line = f.readline()
            if not line:
                print("해당 학생이 없습니다.")
                f.close()
                break
            if line[0:-1] == name:
                f.close()
                return name
        f.close()

    def printStu(self,name:str):
        self.name = name
        f = open(self.name + ".txt", "r", encoding="UTF-8")
        f.readline()
        cnt = 0
        m = 0
        h = 0
        s = 0
        while True:
            line = f.readline()
            if not line:break
            cnt +=1
            lines = line.split(" ")
            h = h + int(lines[6][0:1])
            m = m + int(lines[6][2:4])
            s = s + int(lines[6][5:7])
        f.close()
        m = m + s//60
        s = s%60
        h = h + m//60
        m = m%60
        state = ""
        if 15< cnt and cnt<21:
            state = "관리대상"
        elif cnt<16:
            state = "퇴출대상"
        else:
            state = "정 상"

        print("이름\t출결현황\t총이수시간\t 상태")
        print(name + "\t" + str(cnt) + "/25"+'\t\t' + str(h)+":"+str(m)+":"+str(s) + "\t" + state)


    def delStu(self):
        print("삭제할 학생의 이름을 입력 하세요.")
        opset = 0
        name = input("name : ")
        f = open("student.txt","r",encoding="UTF-8")
        while True:
            line = f.readline()
            if not line : break
            if line[0:-1] == name:
                opset = 1
                break
        f.close()

        if opset == 1:
            print(name+" 학생을 삭제 합니다.")
            f = open("student.txt","r",encoding="UTF=8")
            f2 = open("student_1.txt", "w", encoding="UTF=8")
            while True:
                line = f.readline()
                if not line:break
                if line[0:-1] == name:
                    pass
                else:
                    f2.write(line)

            f.close()
            f2.close()
            os.remove(name+".txt")
            os.remove("student.txt")
            os.rename("student_1.txt","student.txt")
            input("enter를 누르면 다음 화면으로 이동합니다.")
        else:
            print("해당 학생이 없습니다.")
            input("enter를 누르면 다음 화면으로 이동합니다.")


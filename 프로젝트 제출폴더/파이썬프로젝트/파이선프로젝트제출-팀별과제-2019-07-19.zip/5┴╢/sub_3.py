class absent:
    def siyoon(self):
        mon = 0
        tue = 0
        wed = 0
        thu = 0
        fri = 0
        f = open("student.txt","r",encoding="UTF-8")
        while True:
            line = f.readline()
            if not line: break
            f2 = open(line[0:-1] + ".txt","r",encoding="UTF-8")
            f2.readline()
            while True:
                lines = f2.readline()
                if not lines:break
                set = lines.split(" ")
                if set[3] == "Mon":
                    mon = mon+1
                elif set[3] == "Tue":
                    tue = tue +1
                elif set[3] == "Wed":
                    wed = wed +1
                elif set[3] == "Thu":
                    thu = thu +1
                elif set[3] == "Fri":
                    fri = fri +1
            f2.close()
        f.close()
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
        print("요일별 출석 현황")
        print("월", "=" * mon)
        print("화", "=" * tue)
        print("수", "=" * wed)
        print("목", "=" * thu)
        print("금", "=" * fri)
        print()
        input("enter를 누르면 다음 화면으로 이동합니다.")

if __name__ == "__main__":
    a = absent()
    a.siyoon()
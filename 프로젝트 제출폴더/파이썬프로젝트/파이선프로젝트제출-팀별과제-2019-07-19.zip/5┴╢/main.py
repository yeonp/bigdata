import sub_4 #공상균
import sub_0 #공상균
import sub_3 #이시윤
import sub_2 #지원웅
import sub_1 #이수정

weeks = sub_3.absent()
manage = sub_4.Manage()
setTime = sub_0.Time_set()
check = sub_2.Attendance()
total = sub_1.Total()

while True:
    try:
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
        print("출결 관리 프로그램")
        print("1. 종합출결현황\n2. 시간미달자관리\n3. 요일별 출석현황\n4. 학생관리\n5. 종료")
        set = int(input("set : "))
        if set == 1: #종합출결현황
            total.info()
        elif set == 2: #시간미달자 관리
            check.name()

        elif set == 3: #요일별 출석현황
            weeks.siyoon()

        elif set == 4: #학생관리
            while True:
                try:
                    print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                    print("===학생 관리===\n1. 학생추가\n2. 학생검색\n3. 학생삭제\n4. 이전화면")
                    set = int(input("set : "))
                    if set == 1:
                        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                        manage.addStu()
                    elif set == 2:
                        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                        name = manage.searchStu()
                        if name is not None:
                            manage.printStu(name)
                        input("enter를 누르면 다음 화면으로 이동합니다.")
                    elif set == 3:
                        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                        manage.delStu()
                    elif set == 4:
                        break
                    else:
                        print("정확한 번호를 입력해 주세요.")
                        input("enter를 누르면 다음 화면으로 이동합니다.")
                except:
                    print("숫자를 입력해 주세요")
                    input("enter를 누르면 다음 화면으로 이동합니다.")

        elif set == 5:
            print("프로그램 종료!")
            break
        # elif set == 0:
        #     setTime.set_time()
        else:
            print("정확한 번호를 입력해 주세요.")
            input("enter를 누르면 다음 화면으로 이동합니다.")
    except:
        print("숫자를 입력해 주세요")
        input("enter를 누르면 다음 화면으로 이동합니다.")
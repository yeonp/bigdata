# 김유경, 장미소

import csv

dl = []
f = open('restaurant_bigdata.csv','r',encoding='utf-8')
rdr = csv.reader(f)
for line in rdr:
    dl.append(line)
f.close()
# 'restaurant_bigdata.csv' 라는 이름의 csv 파일을 csv.reader()로 읽어온다.
# dl이라는 이름으로 생성된 빈 리스트에 for을 이용해 line 데이터를 추가한다.

def attribute():
    return type(dl[1][0]),type(dl[1][1]),type(dl[1][2]),type(dl[1][3]),type(dl[1][4])
# attribute() 함수
# : type()와 dl 리스트 인덱싱을 이용해서 데이터를 파악한 후 속성을 출력한다.

def dim():
    return len(dl),len(dl[0])
# dim() 함수
# : len()을 이용해 data와 변수의 수를 출력한다.

def head(num=6):
    a = dl[1:num+1]
    for i in a:
        print('\t {0:8} {1:<12} {2:<15} {3:<8} {4:<10} \t'.format(i[0],i[1],i[2],i[3],i[4]))
# head() 함수
# : 함수에 num=6이라는 매개인자를 삽입하고 리스트 슬라이싱을 이용하여 데이터 프레임의 일정 앞 부분의 내용인 6행을 출력한다.

def tail(num=6):
    dl.reverse()
    b=dl[:num]
    b.reverse()
    for i in b:
        print('\t {0:8} {1:<12} {2:<15} {3:<8} {4:<10} \t'.format(i[0], i[1], i[2], i[3], i[4]))
# tail() 함수
# : head()와 비슷한 맥락으로 데이터 프레임에 입력된 리스트의 순서를 거꾸로 뒤집은 후 데이터 프레임의 일정 뒷 부분의 내용인 6행을 출력한다.


import csv
from collections import Counter

A = []
f = open('restaurant_bigdata.csv', 'r', encoding='utf-8')
rdr = csv.reader(f)
for line in rdr:
    A.append(line) # 이중 리스트를 만들어줌
f.close()



def freq_menu():
    q=[]; w=[]; e=[]; r=[]; t=[]
    for i in range(1,len(A)):                        # 전체 메뉴 빈도
        if A[i][2] == '코핫' or A[i][2] == '집밥':
            q.append(A[i][3])
    a=Counter(q)

    for i in range(1, len(A)):                      # 사람별 메뉴 빈도
        if A[i][2] == '코핫' or A[i][2] == '집밥':
            if A[i][1] == '안중현':
                w.append(A[i][3])
    b=Counter(w)

    for i in range(1, len(A)):
        if A[i][2] == '코핫' or A[i][2] == '집밥':
            if A[i][1] == '김유경':
                e.append(A[i][3])
    c=Counter(e)

    for i in range(1, len(A)):
        if A[i][2] == '코핫' or A[i][2] == '집밥':
            if A[i][1] == '장미소':
                r.append(A[i][3])
    d=Counter(r)

    for i in range(1, len(A)):
        if A[i][2] == '코핫' or A[i][2] == '집밥':
            if A[i][1] == '황인규':
                t.append(A[i][3])
    f=Counter(t)

    a['뚝배기닭볶음탕'] += a['뚝닭']
    a['뚝배기불고기'] += a['뚝불']
    b['뚝배기닭볶음탕'] += b['뚝닭']
    b['뚝배기불고기'] += b['뚝불']
    c['뚝배기닭볶음탕'] += c['뚝닭']
    c['뚝배기불고기'] += c['뚝불']
    d['뚝배기닭볶음탕'] += d['뚝닭']
    d['뚝배기불고기'] += d['뚝불']
    f['뚝배기닭볶음탕'] += f['뚝닭']
    f['뚝배기불고기'] += f['뚝불']

    a = a.most_common()
    b = b.most_common()
    c = c.most_common()
    d = d.most_common()
    f = f.most_common()

    print('코핫과 집밥에서 가장 많이 먹은 메뉴 3순위는!! \n {0} 입니다!'.format(a[0:3]))
    print('안중현이 자신있게 추천하는 메뉴:  [ {0} ]'.format(b[0][0]))
    print('김유경이 자신있게 추천하는 메뉴:  [ {0} ]'.format(c[0][0]))
    print('장미소가 자신있게 추천하는 메뉴:  [ {0} ]'.format(d[0][0]))
    print('황인규가 자신있게 추천하는 메뉴:  [ {0} ]'.format(f[0][0]))

#
#
# freq_menu()











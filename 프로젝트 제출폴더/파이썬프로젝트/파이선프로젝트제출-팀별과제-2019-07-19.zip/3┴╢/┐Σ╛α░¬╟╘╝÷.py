# 안중현, 황인규

import csv
from collections import Counter


A = []
f = open('restaurant_bigdata.csv', 'r', encoding='utf-8')
rdr = csv.reader(f)
for line in rdr:
    A.append(line) # 이중 리스트를 만들어줌
f.close()

def frequency(A): # 가게의 빈도 수
    home_cooking = 0; cohat = 0; mommy = 0 # 각각 집밥, 코핫, 마미하우스를 의미함
    for x in range(1, len(A)):
        if A[x][2] == '집밥':
            home_cooking += 1
        elif A[x][2] == '코핫':
            cohat += 1
        elif A[x][2] == '마미하우스':
            mommy += 1
        else:
            pass
    return '집밥 : {0}  코핫 : {1}  마미하우스 : {2}'.format(home_cooking, cohat, mommy)
# print(frequency(A))


def price_add(A): # 가격의 합계
    total = 0
    for x in range(1, len(A)): # 1부터 A의 길이 / A[0][3]은 구분인 가격을 의미하므로
       total = int(A[x][4]) + total
    return '가격의 합계 : {0}'.format(total)
#print(price_add(A))


def price_mean(A): # 가격의 평균
    total = 0
    for x in range(1, len(A)):
        total = int(A[x][4]) + total

    a = total / (len(A)-1)
    return '가격의 평균 : {0}'.format(a)
#print(price_mean(A))


def minimum_value(A): # 가격의 최소값
    y = []
    for x in range(1, len(A)):
        if A[x][4] >= '1000' : # 1000원 이상인 가격의 개수를
            y.append(A[x][4])  # Y의 빈 리스트에 저장, min을 이용해 최소값을 구함
    return '최소값 : {0}'.format(min(y))
#print(minimum_value(A))


def maximum_value(A): # 가격의 최대값
    y = []
    for x in range(1, len(A)):
        if A[x][4] >= '1000' : # 1000원 이상인 가격의 개수를
            y.append(A[x][4])  # Y의 빈 리스트에 저장, max을 이용해 최대값을 구함
    return '최대값 : {0}'.format(max(y))
#print(maximum_value(A))

def person_func(name):  # 사람마다의 요약값들 한번에 출력하기
    b=[]
    for i in range(1, len(A)):
        if A[i][1] == name:
            b.append(A[i])

    print(name,'의 요약값: ')
    print(price_add(b))
    print(price_mean(b))
    print(minimum_value(b))
    print(maximum_value(b))


# person_func('황인규')
# person_func('김유경')
# person_func('장미소')

def person_restaurant_func(name,restaurant):  # 사람마다의 요약값들 한번에 출력하기
    c=[]
    for i in range(1, len(A)):
        if A[i][1] == name and A[i][2] == restaurant:
            c.append(A[i])

    print(name,'가 ',restaurant, '에서 소비한 돈: ')
    print(price_add(c))
    print(price_mean(c))
    print(minimum_value(c))
    print(maximum_value(c))

# person_restaurant_func('황인규','집밥')
# person_restaurant_func('김유경','코핫')
# person_restaurant_func('장미소','집밥')
# person_restaurant_func('안중현','코핫')







def freq_menu():
    q=[]; w=[]; e=[]; r=[]; t=[]
    for i in range(1,len(A)):                        # 전체 메뉴 빈도
        if A[i][2] == '코핫' or A[i][2] == '집밥':
            q.append(A[i][3])
    a=Counter(q)

    for i in range(1, len(A)):                      # 사람별 메뉴 빈도
        if A[i][2] == '코핫' or A[i][2] == '집밥':
            if A[i][1] == '안중현':
                w.append(A[i][3])
    b=Counter(w)

    for i in range(1, len(A)):
        if A[i][2] == '코핫' or A[i][2] == '집밥':
            if A[i][1] == '김유경':
                e.append(A[i][3])
    c=Counter(e)

    for i in range(1, len(A)):
        if A[i][2] == '코핫' or A[i][2] == '집밥':
            if A[i][1] == '장미소':
                r.append(A[i][3])
    d=Counter(r)

    for i in range(1, len(A)):
        if A[i][2] == '코핫' or A[i][2] == '집밥':
            if A[i][1] == '황인규':
                t.append(A[i][3])
    f=Counter(t)

    a['뚝배기닭볶음탕'] += a['뚝닭']
    a['뚝배기불고기'] += a['뚝불']
    b['뚝배기닭볶음탕'] += b['뚝닭']
    b['뚝배기불고기'] += b['뚝불']
    c['뚝배기닭볶음탕'] += c['뚝닭']
    c['뚝배기불고기'] += c['뚝불']
    d['뚝배기닭볶음탕'] += d['뚝닭']
    d['뚝배기불고기'] += d['뚝불']
    f['뚝배기닭볶음탕'] += f['뚝닭']
    f['뚝배기불고기'] += f['뚝불']

    a = a.most_common()
    b = b.most_common()
    c = c.most_common()
    d = d.most_common()
    f = f.most_common()

    print('코핫과 집밥에서 가장 많이 먹은 메뉴 3순위는!! \n {0} 입니다!'.format(a[0:3]))
    print('안중현이 자신있게 추천하는 메뉴:  [ {0} ]'.format(b[0][0]))
    print('김유경이 자신있게 추천하는 메뉴:  [ {0} ]'.format(c[0][0]))
    print('장미소가 자신있게 추천하는 메뉴:  [ {0} ]'.format(d[0][0]))
    print('황인규가 자신있게 추천하는 메뉴:  [ {0} ]'.format(f[0][0]))

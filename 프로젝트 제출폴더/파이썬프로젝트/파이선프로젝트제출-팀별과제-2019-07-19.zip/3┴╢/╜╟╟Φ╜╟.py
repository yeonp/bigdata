
# 3조: 안중현, 김유경, 장미소, 황인규
# 주제: 점심기록장

import 입출력프로그램 as input
import 속성출력함수 as yg
import 요약값함수 as jh

class lunch:
    def __init__(self):
       self.list = []

    def input(self):
        self.list = input.Sales()

    def summary(self, func=0):
        if func == 0:
            print('''
                1: frequency(restaurant_name)
                2. sum(price)
                3. mean(price)
                4. min(price)
                5. max(price)
            ''')
        elif func == 1:
            a = jh.frequency(self.list)
            return a
        elif func == 2:
            a= jh.price_add(self.list)
            return a
        elif func == 3:
            a = jh.price_mean(self.list)
            return a
        elif func == 4:
            a = jh.minimum_value(self.list)
            return a
        elif func ==5:
            a = jh.maximum_value(self.list)
            return a

    def pf(self, name):
        jh.person_func(name)

    def prf(self, name, restaurant):
        jh.person_restaurant_func(name, restaurant)

    def menu_frq(self):
        jh.freq_menu()

    def dim(self):
        return yg.dim()

    def head(self):
        return yg.head()

    def tail(self):
        return yg.tail()

    def type(self):
        return yg.attribute()




if __name__ == '__main__':
    lun1 = lunch()

    lun1.input()

    lun1.summary()

    for i in range(1,6):
        print(lun1.summary(i))

    lun1.pf('장미소')
    lun1.prf('장미소','집밥')

    lun1.menu_frq()


    print(lun1.dim())
    lun1.head()
    lun1.tail()
    print(lun1.type())










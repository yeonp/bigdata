def passed():
    import random
    import os
    from dataframe import get_dataframe
    A_level = [1, 1, 1, 1, 1, 1, 1, 1, 0, 0]
    B_level = [1, 1, 1, 1, 1, 1, 0, 0, 0, 0]
    C_level = [1, 1, 1, 0, 0, 0, 0, 0, 0, 0]
    if os.path.isfile('study_cal.txt') == True:
        f = open('study_com.txt', 'w', )
        f.close()
    cal = open('study_cal.txt', 'r')
    com = open('study_com.txt', 'a')
    while True:
        line = cal.readline()
        if not line: break
        row = line.split()
        my_g = row[7]
        my_grade = my_g
        if my_grade == 'A':
            a_choice = random.choice(A_level)
            if a_choice == 1:
                result = 'pass'
                com.write(line[:-1] + ' ' + result + '\n')
                return '당신은 %s'%result
            else:
                result = 'fail'
                com.write(line[:-1] + ' ' + result + '\n')
                return '당신은 %s' % result
        elif my_grade == 'B':
            b_choice = random.choice(B_level)
            if b_choice == 1:
                result = 'pass'
                com.write(line[:-1] + ' ' + result + '\n')
                return '당신은 %s' % result
            else:
                result = 'fail'
                com.write(line[:-1] + ' ' + result + '\n')
                return '당신은 %s' % result
        elif my_grade == 'C':
            c_choice = random.choice(C_level)
            if c_choice == 1:
                result = 'pass'
                com.write(line[:-1] + ' ' + result + '\n')
                return '당신은 %s' % result
            else:
                result = 'fail'
                com.write(line[:-1] + ' ' + result + '\n')
                return '당신은 %s' % result


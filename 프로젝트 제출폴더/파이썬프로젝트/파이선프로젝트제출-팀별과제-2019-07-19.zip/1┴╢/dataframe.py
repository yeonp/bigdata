def get_line():
    hero = open('study_hero.txt', 'r', encoding='UTF-8')
    l = {}
    while True:
        line = hero.readline()
        if not line: break
        row = line.split()
        name, knowledge,sociability, independence,condition = row
        k = int(knowledge)
        s = int(sociability)
        i = int(independence)
        c = int(condition)
        l[name] = k,s,i,c
    return l

def get_dataframe():
    cal = open('study_cal.txt', 'r')
    l = {}
    bin = {'name': 0, 'knowledge': 0, 'sociability': 0, 'independence': 0, 'condition': 0, 'sum': 0, 'avg': 0,
           'grade': 0}
    while True:
        line = cal.readline()
        if not line: break
        row = line.split()
        name, knowledge, sociability, independence, condition, sum, avg, grade = row
        k = int(knowledge)
        s = int(sociability)
        i = int(independence)
        c = int(condition)
        sum = int(sum)
        avg = int((round(float(avg))))
        grade = str(grade)
        l[name] = k,s,i,c,sum,avg,grade

        # #-------------------------------------------------------
        # #   네임으로 만들기
        key = l.keys()
        l_k = list(key)
        # print(l_k)
        # # -----------------------------------------------------
        # #   각각의 값 입력
        val = l.values()
        l_v = list(val)
        # print(l_v)
        d1 = []
        d2 = []
        d3 = []
        d4 = []
        d5 = []
        d6 = []
        d7 = []
        print('-'*50)
        for y in range(len(l)):
            z = 0
            d1.append(l_v[y][z])
        # print(d1)

        for y in range(len(l)):
            z = 1
            d2.append(l_v[y][z])
        # print(d2)

        for y in range(len(l)):
            z = 2
            d3.append(l_v[y][z])
        # print(d3)

        for y in range(len(l)):
            z = 3
            d4.append(l_v[y][z])
        # print(d4)

        for y in range(len(l)):
            z = 4
            d5.append(l_v[y][z])

        for y in range(len(l)):
            z = 5
            d6.append(l_v[y][z])

        for y in range(len(l)):
            z = 6
            d7.append(l_v[y][z])

        bin['name'] = l_k
        bin['knowledge'] = d1
        bin['sociability'] = d2
        bin['independence'] = d3
        bin['condition'] = d4
        bin['sum'] = d5
        bin['avg'] = d6
        bin['grade'] = d7
    return bin


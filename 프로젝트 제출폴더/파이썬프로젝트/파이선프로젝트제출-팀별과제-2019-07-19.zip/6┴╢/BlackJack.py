import random
import csv

# dataframe 클래스

class BlackJack:

    def __init__(self):
        self.deck = ['A', 2, 3, 4, 5, 6, 7, 8, 9, 10, 'J', 'Q', 'K'] * 4        # 스페이드, 다이아, 하트, 클로버 4가지
        self.dealer_deck = []       # 딜러가 갖고있는 카드
        self.user_deck = []         # 사용자가 갖고있는 카드
        self.wallet = 100000        # 처음 주어지는 금액
        self.betting = 0

    def firstdeal(self, deck):                       # 첫 두장 분배
        mydeck = []
        for i in range(2):
            random.shuffle(deck)            # 함수에 인자로 들어오는 deck list의 원소들을 섞어준다.
            card = deck.pop()               # 섞인 리스트에서 맨 끝의 원소를 뽑아낸다.
            mydeck.append(card)             # 뽑아낸 원소들로 리스트를 채운다.
        return mydeck

    def score(self, deck):
        if deck == self.user_deck:
            if 'A' in deck:
                print(self.user_deck)
                select_A = int(input('A를 숫자 몇으로 하시겠습니까?(1, 11) : '))
                idx = deck.index('A')
                deck.pop(idx)
                deck.append(select_A)
        if deck == self.dealer_deck:
            if 'A' in deck:
                idx = deck.index('A')
                deck.pop(idx)
                deck.append(11)
                if sum(deck) > 21:
                    idx = deck.index(11)
                    deck.pop(idx)
                    deck.append(1)
        if 'J' in deck:
            idx = deck.index('J')
            deck.pop(idx)
            deck.append(10)
        elif 'Q' in deck:
            idx = deck.index('Q')
            deck.pop(idx)
            deck.append(10)
        elif 'K' in deck:
            idx = deck.index('K')
            deck.pop(idx)
            deck.append(10)

        total = sum(deck)

        return total

    def scoring(self):
        print('\n딜러의 카드는 {0} 이며 점수는 {1} 입니다.'.format(self.dealer_deck, self.score(self.dealer_deck)))
        print('당신의 카드는 {0} 이며 점수는 {1} 입니다.'.format(self.user_deck, self.score(self.user_deck)))

        if self.score(self.user_deck) < self.score(self.dealer_deck):
            print('딜러의 점수보다 낮아 게임에서 졋습니다.')
            self.wallet -= self.betting
            self.csv(2, '', self.betting)
            print('{0}원을 잃고 {1}원이 되었습니다.'.format(self.betting, self.wallet))
        elif self.score(self.dealer_deck) < self.score(self.user_deck):
            print('딜러의 점수보다 높아 게임에서 이겼습니다!')
            self.wallet += self.betting
            self.csv(1, self.betting)
            print('{0}원을 벌고 {1}원이 되었습니다.'.format(self.betting, self.wallet))
        elif self.score(self.dealer_deck) == self.score(self.user_deck):
            print('딜러와 점수가 같습니다.')
            self.csv(3)
        self.restart()

    def restart(self):
        restart = input('다시 하시겠습니까?(Y/N) : ')
        if restart == 'y' or 'Y':
            self.play()
        elif restart == 'n' or 'N':
            exit()

    def bust(self):             # 21초과시 패
        ud = int(self.score(self.user_deck))
        dd = int(self.score(self.dealer_deck))
        # print(ud, dd)
        if ud > 21 and dd > 21:
            # print('testcode\ndealer : {0}\nuser : {1}'.format(self.score(self.user_deck), self.score(self.dealer_deck)))
            print('\n딜러의 카드는 {0} 이며 점수는 {1} 입니다.'.format(self.dealer_deck, self.score(self.dealer_deck)))
            print('당신의 카드는 {0} 이며 점수는 {1} 입니다.'.format(self.user_deck, self.score(self.user_deck)))
            print('딜러와 동시에 21점을 초과해 무승부입니다.')
            self.csv(3, '', '')
            self.restart()
        elif ud > 21:
            print('\n딜러의 카드는 {0} 이며 점수는 {1} 입니다.'.format(self.dealer_deck, self.score(self.dealer_deck)))
            print('당신의 카드는 {0} 이며 점수는 {1} 입니다.'.format(self.user_deck, self.score(self.user_deck)))
            print('당신의 점수가 21점을 초과해 졌습니다.')
            self.wallet -= self.betting                          # 갖고 있던 잔액에 배팅금액을 뺀값을 넣는다
            print('{0}원을 잃고 {1}원이 되었습니다.'.format(self.betting, self.wallet))
            self.csv(2, '', self.betting)
            self.restart()                                       # 재시작 함수 호출
        elif dd > 21:
            print('\n딜러의 카드는 {0} 이며 점수는 {1} 입니다.'.format(self.dealer_deck, self.score(self.dealer_deck)))
            print('당신의 카드는 {0} 이며 점수는 {1} 입니다.'.format(self.user_deck, self.score(self.user_deck)))
            print('딜러의 점수가 21점을 초과해 이겼습니다!')
            self.wallet += self.betting
            print('{0}원을 벌고 {1}원이 되었습니다.'.format(self.betting, self.wallet))
            self.csv(1, self.betting)
            self.restart()

    def play(self):                                              # 메인
        select = 0                                               # Hit, Stay, Surrender
        print('블랙잭을 시작합니다.\n보유 자산 : {}'.format(self.wallet))
        if self.wallet == 0:                                     # 지갑에 돈이 없으면 실행
            print('돈을 모두 사용해 충전합니다.')
            self.wallet += 50000
            print('보유자산 : {}'.format(self.wallet))
        betting = int(input('얼마를 배팅하겠습니까? : '))
        if betting > self.wallet:
            print('잔액이 부족합니다. 다시 입력해 주세요')
            betting = int(input('얼마를 배팅하겠습니까? : '))
        self.betting = betting
        self.dealer_deck = self.firstdeal(self.deck)             # 최초 배팅 실행
        self.user_deck = self.firstdeal(self.deck)
        self.bust()
        if self.score(self.dealer_deck) == 21:                   # 첫 2장의 카드 합이 21이면 블랙잭
            print('딜러가 블랙잭이에요. 당신이 졌습니다!')
            self.wallet = self.wallet - self.betting
            print('남은 금액 : {}'.format(self.wallet))
            self.csv(2, '', self.wallet - self.betting)
            self.restart()
        elif self.score(self.user_deck) == 21:
            print('블랙잭이군요. 당신이 이겼습니다!')
            self.wallet = self.betting * 1.5
            print('남은 금액 : {}'.format(self.wallet))
            self.csv(1, self.betting * 1.5)
            self.restart()
        while select != 2:
            print('딜러의 첫번째 카드는 {0} 입니다.'.format(self.dealer_deck[0]))
            print('당신의 카드는 {0} 입니다.'.format(self.user_deck))
            self.bust()

            print('1. Hit : 추가카드 요청\n2. Stay : 추가카드 거부\n3. Surrender : 게임 포기')
            select = int(input('무엇을 하시겠습니까?'))
            if select == 1:                                       # Hit
                card = self.deck.pop()
                self.user_deck.append(card)
                if self.score(self.dealer_deck) < 17:
                    card = self.deck.pop()
                    self.dealer_deck.append(card)
                self.bust()
            elif select == 2:                                     # Stay
                while self.score(self.dealer_deck) < 17:
                    card = self.deck.pop()
                    self.dealer_deck.append(card)
                    self.bust()
                self.bust()
                self.scoring()
            elif select == 3:                                     # Surrender
                self.wallet -= self.betting / 2
                money = self.betting / 2
                print('포기하셨습니다. {0}을 잃었습니다.'.format('돈'))
                with open('dataframe.csv', 'a', newline='', encoding='utf-8') as f:
                    wr = csv.writer(f)
                    wr.writerow([self.betting, self.user_deck, self.score(self.user_deck), '패배', '', money, self.wallet])
                    f.close()
                self.restart()

    def csv(self, num, addm = '', subm = ''):
        if num == 1:
            with open('dataframe.csv', 'a', newline='', encoding='utf-8') as f:
                wr = csv.writer(f)
                wr.writerow([self.betting, self.user_deck, self.score(self.user_deck), '승리', addm, subm, self.wallet])
                f.close()
        if num == 2:
            with open('dataframe.csv', 'a', newline='', encoding='utf-8') as f:
                wr = csv.writer(f)
                wr.writerow([self.betting, self.user_deck, self.score(self.user_deck), '패배', addm, subm, self.wallet])
                f.close()
        if num == 3:
            with open('dataframe.csv', 'a', newline='', encoding='utf-8') as f:
                wr = csv.writer(f)
                wr.writerow([self.betting, self.user_deck, self.score(self.user_deck), '무승부', addm, subm, self.wallet])
                f.close()


if __name__ == '__main__':
    playblackjack = BlackJack()
    playblackjack.play()

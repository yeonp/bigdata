class English: # 작성자 : 강민구

    def __init__(self):
        self.score = 0
        self.namelist =input('이름을 입력하세요 :')

    def word_test(self): # 게임실행
        import os
        words = {
                'apple': ['사과'],
                'germ': ['세균', '미생물'],
                'vertical' : ['수직의', '세로의'],
                'horizontal' : ['수평의', '가로의'],
                'assemble' : ['모으다', '모이다', '집합시키다'],
                'day' : ['날짜', '일'],
                'graze' : ['풀을 뜯다','방목하다','가볍게 스치다'],
                'inscribe' : ['쓰다','적다','새기다'],
                'praise' : ['칭찬하다','찬사','높이 평가하다', '칭송하다','호평'],
                'track' : ['추적하다','트랙','궤도','기록','곡']
            }
        count = 0
        question_num = len(words.items())
        for i in range(1000):
            if count == question_num:
                print('모든 문제를 맞추셨습니다!\n')
                print('score: ', '총', self.score, '점')
                os.system('pause')
                break
            if i == 0:
                words_copy = words.copy()
                print(i + 1, '회차입니다.')
                for word, answer in words.items():
                    user_answer = input('{} : '.format(word))
                    directed_word = words[word]

                    try:
                        self.score = 10 + self.score # 문제를 맞히면 10점 증가
                        if directed_word.index(user_answer) < len(directed_word):
                            print()
                            print('맞았습니다!\n{} : {}'.format(word, answer))
                            print('score: ', self.score, '점')
                            print()
                            count += 1
                            del words_copy[word]
                    except:
                        self.score = self.score - 10 # 문제를 틀리면 10점 감소
                        print()
                        print('틀렸습니다.\n{} : {}'.format(word, answer))
                        print('score: ', self.score, '점')
                        print()

                    print('닉네임:', self.namelist, '총점: ',  self.score)

        f = open('score.csv','a',encoding='utf-8')
        f.write(self.namelist + ',')
        f.write(str(self.score)+ '\n')      #게임 결과 저장
        f.close()
if __name__ == '__main__':
    test = English()
    test.word_test()
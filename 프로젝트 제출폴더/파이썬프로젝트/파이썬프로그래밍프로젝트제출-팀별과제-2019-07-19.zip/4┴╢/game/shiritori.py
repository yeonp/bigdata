import random
class humanEg(): # player의 동작
    def humanInput(lastChar): # lastChar : 마지막으로 입력한 단어의 끝 알파벳
        print("Human : ", lastChar,end="")
        humanWord = input("")
        return humanWord

    def humanConnectChar(humanInputWord,plusChar): # 끝 알파벳과 입력된 글자를 합쳐 humanWord로 반환
        humanWord = str(plusChar) + str(humanInputWord)
        return humanWord

    def humanWordDefine(hmWord,dicData): # 입력한 문자가 사전 데이터에 포합되어있는지 검증
        for dicWord in dicData:
           if dicWord == hmWord:
                return False
        return True

    def humanUseWord(hmWord,useData):  # 사용한 단어를 또 쓰는것을 불가능하게하는 함수
        for useWord in useData:
            if hmWord == useWord:
                print("이미 사용한 단어입니다.")
                return True
        return False

class computerEg():  # 컴퓨터의 동작
    def useWord(lastChar,dicData):  # 사전데이터에서 직접 플레이어가 입력한 끝 알파벳으로 시작하는 단어를 출력
        #마지막글자와 첮번째 글짜가 같은것들을 리스트로 묶기
        canUse = []
        for dicWord in dicData:
            try:
                firstChar = dicWord[0]
            except:
                pass
            if firstChar == lastChar:
                canUse.append(dicWord)
            else:
                continue
        return canUse

    def useAgain(word,useData): # 사전데이터에서 컴퓨터가 사용한 데이터 제외
        for use in useData:
            try:
                word.remove(use)
            except:
                pass
        return word

    def selectWord(canUse):
        wordLen = len(canUse)-1
        useWord = canUse[random.randint(0,wordLen)]
        return useWord

    def useDataJoin(word,useData):
        useData = useData.append(word)
        return useData

class defaultEg():
    def getLastChar(word):
        #맨 마지막 단어 구하기
        Len = len(word)
        return word[Len - 1]

    def getFisrtChar(word):
        return word[0]

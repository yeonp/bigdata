import random
import time

class Mine():
    def __init__(self):
        self.mine = []
        self.num = int(input("N x N 프레임을 만듭니다. 숫자를 입력하시오:"))
        self.str = ""
        self.score = 0
        self.mine_location = random.randint(0, self.num * self.num - 1)
        self.game_time= 0
        self.game_time_start = time.time()
        self.name = input("이름을 입력하세요 : ")
        print('score :',self.score, '  game_time:', self.game_time)
        print('data_frame : ', self.num, 'X', self.num)
        for i in range(0, self.num * self.num):
            if i == self.mine_location:
                self.mine.append(["*", False])
            else:
                self.mine.append(["*", True])

        for i in range(len(self.mine)):
            if (i + 1) % self.num is 0:
                self.str += self.mine[i][0] + " \n"
            else:
                self.str += self.mine[i][0] + " "
        print(self.str)

    def mine_print(self):
        mine_str = ""
        for i in range(len(self.mine)):
            if (i + 1) % self.num is 0:
                mine_str += self.mine[i][0] + " \n"
            else:
                mine_str += self.mine[i][0] + " "
        print('score :', self.score)
        print(mine_str)

    def find_mine(self):
        while True:
            self.x = int(input("원하는 행을 고르시오 : "))
            self.y = int(input("원하는 열을 고르시오 : "))
            score = 10 + self.score
            self.score = score
            if self.x > self.num or self.y > self.num:
                print("숫자가 프레임 범위를 넘었습니다.")
                continue

            if self.mine[(self.x - 1) * self.num + self.y - 1][1]:
                self.mine[(self.x - 1) * self.num + self.y - 1][0] = "X"
                print("Try again!")
                self.mine_print()
                continue
            else:
                self.mine[(self.x - 1) * self.num + self.y - 1][0] = "O"
                self.mine_print()
                print("Mine Boom!")
                game_time_end = time.time()
                self.game_time = round(game_time_end - self.game_time_start)
                print('total score :', self.score, '  total game_time:', self.game_time, '초')
                print('게임이 끝났습니다. 수고하셨습니다.')
                return

        f = open('score.csv', 'a', encoding='utf-8')
        f.write(self.name + ', ')
        f.write(str(self.score) + '\n')
        f.close()

if __name__ == '__main__':
    test = Mine()
    test.find_mine()

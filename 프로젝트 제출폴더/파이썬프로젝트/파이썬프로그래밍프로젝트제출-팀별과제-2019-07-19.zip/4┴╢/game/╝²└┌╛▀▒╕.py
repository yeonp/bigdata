import random

class num_baseball:   # 작성자 : 최인빈

    def __init__(self):
        self.number = [1, 2, 3] # 랜덤으로 생성될 숫자를 위한 리스트
        self.number[0] = random.choice(range(10))
        self.number[1] = random.choice(range(10))
        self.number[2] = random.choice(range(10))   # 세자리 숫자 랜덤 생성
        self.score = 0   # 점수
        self.name = ' '  # 이름
    def base(self):  # 숫자 야구 게임 실행
        self.name = input("이름을 입력하세요 : ")
        while True:
            print("숫자 3개를 입력하세요")

            input_number = input("첫번째 자리 숫자를 입력하세요~> ")
            strike = 0
            ball = 0
            out = 0
            count = 0

            if int(input_number) in range(100, 1000):

                for n in range(3):          # 정답 여부 판별
                    if int(input_number[n]) == self.number[n]:
                        strike += 1
                        count += 1
                    if int(input_number[n]) in self.number:
                        ball += 1
                        count += 1
                    else:
                        out += 1
                        count += 1
                if strike == 3:
                    print("정답입니다", count,'회')
                    self.score = self.score + (100 - count)
                    print(self.name,'님의 점수는',self.score,'점 입니다')

                    break
                else:
                    print('결과는 strike {}번, ball {}번, out {}입니다. 다시하세요'.format(strike, ball, out))

            else:
                print("범위내의 숫자를 입력해주세요~ (100~ 999까지!)")

        f = open('Score.csv', 'a', encoding='utf-8')        # 결과 저장
        f.write(self.namelist + ', ')
        f.write(str(self.score) + '\n')
        f.close()
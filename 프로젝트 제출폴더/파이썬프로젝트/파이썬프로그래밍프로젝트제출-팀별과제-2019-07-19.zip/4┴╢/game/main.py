import random
import time
# import requests, re
# from bs4 import BeautifulSoup
from collections import OrderedDict
import sys,os
# import pandas as pd

menu = '''      **** 종합 게임 ****
    1. 숫자 야구
    2. 지뢰 찾기
    3. 끝말 잇기
    4. 행맨
    5. UP & DOWN
    6. 영단어 퀴즈
    7. 윷놀이
    0 . 종료
     '''

class hangman: # 작성자 : 최인빈
    HANGMANPICS = [

        '''



      +---+

      |   |

          |

          |

          |

          |

    =========''',

        '''



      +---+

      |   |

      O   |

          |

          |

          |

    =========''',

        '''



      +---+

      |   |

      O   |

      |   |

          |

          |

    =========''',

        '''



      +---+

      |   |

      O   |

     /|   |

          |

          |

    =========''',

        '''



      +---+

      |   |

      O   |

     /|\  |

          |

          |

    =========''',

        '''



      +---+

      |   |

      O   |

     /|\  |

     /    |

          |

    =========''',

        '''



      +---+

      |   |

      O   |

     /|\  |

     / \  |

          |

    =========''']

    words = 'ant baboon badger bat bear beaver camel cat clam cobra cougar coyote crow deer dog donkey duck eagle ferret fox frog goat goose hawk lion lizard llama mole monkey moose mouse mule newt otter owl panda parrot pigeon python rabbit ram rat raven rhino salmon seal shark sheep skunk sloth snake spider stork swan tiger toad trout turkey turtle weasel whale wolf wombat zebra'.split()
    # 게임에 사용할 단어
    def __init__(self):
        pass

    def getRandomWord(self, wordList):

        # 이 함수는 전달된 문자열 목록에서 임의의 문자열을 반환한다

        wordIndex = random.randint(0, len(wordList) - 1)

        return wordList[wordIndex]

    def displayBoard(self, HANGMANPICS, missedLetters, correctLetters, secretWord):

        print(HANGMANPICS[len(missedLetters)])

        print()

        print('틀린 알파벳 : ', end=' ')

        for letter in missedLetters:
            print(letter, end=' ')

        print()

        blanks = '_' * len(secretWord)

        for i in range(len(secretWord)):  # 빈칸을 정답으로 대체

            if secretWord[i] in correctLetters:
                blanks = blanks[:i] + secretWord[i] + blanks[i + 1:]

        for letter in blanks: #각 글자 사이에 공백이 있는 정답 표시

            print(letter, end=' ')

        print()

    def getGuess(self, alreadyGuessed):

        # 플레이어가 입력한 알파벳을 반환한다. 이 기능은 플레이어가 다른 것이 아닌 하나의 문자를 입력하도록 한다.

        while True:

            print('알파벳을 입력하세요.')

            guess = input()

            guess = guess.lower()

            if len(guess) != 1:

                print('한 글자만 입력해주세요.')

            elif guess in alreadyGuessed:

                print('이미 사용한 알파벳입니다. 다시 입력하세요.')

            elif guess not in 'abcdefghijklmnopqrstuvwxyz':

                print('알파벳을 입력하세요.')

            else:

                return guess

    def playAgain(self):

        # This function returns True if the player wants to play again, otherwise it returns False.

        print('한번 더 하시겠습니까? (yes or no)')

        return input().lower().startswith('y')

class General_game:



    def start_game(self):

        print(menu)
        a = int(input(" 게임을 선택 하세요  : "))

        if a == 1:
            import 숫자야구

            print("""



=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
                        숫  자  야  구 
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=



-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
""", end="")
            base = 숫자야구.num_baseball()
            base.base()
        if a == 2:
            print("""



=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
                        지  뢰  찾  기 
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=



-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
""", end="")
            import 지뢰찾기
            mine = 지뢰찾기.Mine()
            mine.find_mine()
        if a == 3:
            import shiritori

            dicData = []  # 사전목록
            useData = []  # 이미사용된 단어 저장
            lastChar = ""
            try:
                f = open("system.txt", "r") # 사전 열기
            except:
                print("ERROR! system.txt file not found!")
                print("Loading system.txt  [ FAULT ]")
                time.sleep(5)

            while True:
                data = f.readline().rstrip('\r\n')
                dicData.append(data)
                if data == "":
                    break

            f = open("system.txt", "r")
            print("""




=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
                        끝 말 잇 기 
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=



-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
""", end="")
            # 스타트 루프
            while True:
                name = input('이름을 입력하세요!')
                hmWord = shiritori.humanEg.humanInput(lastChar)  # 사람이 단어를 입력함
                hmWord = shiritori.humanEg.humanConnectChar(hmWord, lastChar)  # 사람이 입력 한 단어를 가공함
                hmCanUse = shiritori.humanEg.humanWordDefine(hmWord, dicData)  # 사람이 입력한 단어가 있는지 확인
                if hmCanUse:
                    print("이 단어는 없는거 같습니다..")
                    continue
                isuse = shiritori.humanEg.humanUseWord(hmWord, useData)
                if isuse:
                    continue
                else:
                    useData.append(hmWord)

                # 사람이 입력할것이 완료됨
                # 컴퓨터의 시작
                lastChar = shiritori.defaultEg.getLastChar(hmWord)
                comWord = shiritori.computerEg.useWord(lastChar, dicData)
                if comWord == []:
                    score = 1000
                    print("끄악! 컴퓨터가 졌습니다.")
                    print("다시 시작하려면 프로그램을 다시시작하십시오.")
                    time.sleep(2)
                    f = open('score.csv', 'a', encoding='utf-8')  # 결과 저장
                    f.write(name + ' ')
                    f.write(str(score) + '\n')
                    f.close()

                comWord = shiritori.computerEg.useAgain(comWord, useData)
                if comWord == []:
                    score = 1000
                    print("끄악! 컴퓨터가 졌습니다.")
                    print("다시 시작하려면 프로그램을 다시시작하십시오.")
                    time.sleep(2)
                    f = open('score.csv', 'a', encoding='utf-8')  # 결과 저장
                    f.write(name + ', ')
                    f.write(str(score) + '\n')
                    f.close()


                # comWord  변수에 총 사용가능한 단어들이 모여있습니다.
                computerUse = shiritori.computerEg.selectWord(comWord)
                print("Computer : ", computerUse)
                useData.append(computerUse)
                lastChar = shiritori.defaultEg.getLastChar(computerUse)
                # 엔진구동 완료. 다시 시작
        if a == 4:


            hang = hangman()

            print("""




=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
                      H A N G M A N  
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=



-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
""", end="")
            missedLetters = ''
            correctLetters = ''
            secretWord = hang.getRandomWord(hang.words)
            gameIsDone = False
            score = 0
            name = input('이름을 입력하세요 : ')

            while True:

                hang.displayBoard(hang.HANGMANPICS, missedLetters, correctLetters, secretWord)

                # Let the player type in a letter.
                guess = hang.getGuess(missedLetters + correctLetters)

                if guess in secretWord:

                    correctLetters = correctLetters + guess

                    # Check if the player has won

                    foundAllLetters = True

                    for i in range(len(secretWord)):

                        if secretWord[i] not in correctLetters:
                            foundAllLetters = False

                            break

                    if foundAllLetters:
                        print('정답은  "' + secretWord + '" 당신의 승리입니다!')
                        score = score + 100
                        print(name,'님',score ,'점 획득! ')
                        f = open('Score.csv','a',encoding='utf-8')
                        f.write(name+', ')
                        f.write(str(score)+'\n')
                        f.close()

                        gameIsDone = True

                else:

                    missedLetters = missedLetters + guess

                    # Check if player has guessed too many times and lost

                if len(missedLetters) == len(hang.HANGMANPICS) - 1:
                    hang.displayBoard(hang.HANGMANPICS, missedLetters, correctLetters, secretWord)

                    print(
                        'You have run out of guesses!\nAfter ' + str(len(missedLetters)) + ' missed guesses and ' + str(
                            len(correctLetters)) + ' correct guesses, the word was "' + secretWord + '"')

                    gameIsDone = True

                    # Ask the player if they want to play again (but only if the game is done).

                if gameIsDone:

                    if hang.playAgain():

                        missedLetters = ''

                        correctLetters = ''

                        gameIsDone = False

                        secretWord = hang.getRandomWord(hang.words)

                    else:

                        break
        if a == 5:
            import updown
            u = updown.updown()
            print("""

            


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
                       U P & D O W N  
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=



-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
""", end="")

            u.play()
            u.save_score()
        if a == 6:
            import 영단어게임
            print("""



=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
                    영  단  어  게  임 
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=



-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
""", end="")
            e = 영단어게임.English()
            e.word_test()
        if a == 7:
            print("""



=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
                        윷   놀   이
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=



-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
""", end="")
            import 윷놀이
            y = 윷놀이.yougame()
            y.table()

game = General_game()

while True:
    st = input('게임을 실행 하시겠습니다. y/n')
    if st == 'y':
        game.start_game()
    if st == 'n':
        break

def rank():
    f = pd.read_csv('Score.csv',encoding='utf-8')
    a = f.groupby('name').sum()
    a.sort_values(by = 'score',ascending=False,inplace=True)
    print(a)
    # f = open('Score.csv','r',encoding='utf-8')
    # name = []
    # score= []
    # dic = {}
    # count = 0
    # while True:
    #     line = f.readline()
    #     if not line: break
    #     row = line.split()
    #     name.append(row[0])
    #     score.append(row[1])


rank()




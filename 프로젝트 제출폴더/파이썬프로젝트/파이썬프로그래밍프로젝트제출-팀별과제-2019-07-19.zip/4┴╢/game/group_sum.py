class data_frame:
    def __init__(self):
        self.count = 0
        self.var1 = 0
        self.var2 = 0

    def group_sum(self, name, group, var1):
        f = open('{0}.txt'.format(name), 'r', encoding='UTF-8')
        header = f.readline()
        header_list = header.split()
        for x in range(len(header_list)):
            if header_list[x] == group:
                self.var2 = x

        for x in range(len(header_list)):
            if header_list[x] == var1:
                self.var3 = x


        print('{0:5}'.format(header_list[self.var2]), '          ', header_list[self.var3])
        print('{0:20}'.format('----------------------'))
        data_list = []
        namelist = []

        while True:
            line = f.readline()
            self.count = 1 + self.count
            if not line: break
            row = line.split()
            data_list.append(row)
        for x in range(self.count - 1):
            namelist.append(data_list[x][self.var2])
        namelist = list(set(namelist))
        for x in range(0, len(namelist)):
            sum = 0
            for y in range(self.count - 1):
                if namelist[x] == data_list[y][self.var2]:
                    sum = int(data_list[y][self.var3]) + sum
            print('{0:5}'.format(namelist[x]), '          ', sum)

if __name__ == '__main__':
    k = data_frame()
    k.group_sum('Score', 'name', 'score')
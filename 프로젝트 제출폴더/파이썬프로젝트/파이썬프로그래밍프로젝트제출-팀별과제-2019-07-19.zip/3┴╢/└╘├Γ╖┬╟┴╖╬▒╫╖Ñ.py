# 안중현, 장미소, 김유경, 황인규

jibbob_dict = {'김치찌개':6000,'참치찌개':6000,'된장찌개':6000,'청국장':6000,'순두부찌개':6000,'부대찌개':6500,
            '제육볶음':6500,'뚝배기불고기':6500,'뚝배기닭볶음탕':6500,'치즈계란찜':6000,'닭곰탕':6500,'뚝불':6500,'뚝닭':6500}
cohot_dict = {'코핫김밥':1500,'참치김밥':3000,'치즈김밥':3000,'돈가스김밥':3000,'새우튀김김밥':3000,'오징어튀김김밥':3000,
            '참치땡초김밥':3500,'소고기김밥':3500,'제육덮밥':5000,'오징어덮밥':5000,'김치볶음밥':5000,'돌솥비빕밥':5000,
              '등심돈가스':4500,'치즈돈가스':6000,'고구마치즈돈가스':6000,'순두부찌개':5000,'부대찌개':5000,'된장찌개':5000,'김치찌개':5000,
              '육개장':5000, '소불고기뚝배기':6000,'코핫떡볶이':2500,'치즈추가':1000,'꼬치어묵':2500,'라볶이':4000,'김말이':1500, '오징어':1500,
              '새우':1500, '치즈스틱':1500,'보양식 지리삼계탕':12000,'시원냉면':6000,'모듬튀김(대)':6000,'모듬튀김(소)':4000,'코핫세트':10000,
            '치떡돈가스':7000,'수제비':5000,'쫄면':4000,'튀김우동':4000,'어묵우동':3500,'우동':3500,'해물라면':4500,
            '치즈라면':3500,'라면':3000,'맛감자':1000,'튀오뎅':1000,'튀김만두':1500,'매콤불고기마요컵밥':3000}


def Sales():
    '''
    이 함수는
    저희 조가 각자 먹었던 식당과 메뉴들을 입력하는 부분과
    여태까지 입력되었던 자료들을 출력하는 부분,
    마지막으로 가장 최근에 입력된(마지막으로 입력된) 자료를 한줄씩 삭제하는 기능으로 이루어져있습니다.

    이 중, 메뉴까지 등록된 식당은 집밥과 코핫 두군데이며, 나머지 식당(마미하우스, 밥풀)의 경우 빈도가 적고, 메뉴를 정확히 알지 못해
    인위적으로 제외하여 식당이름은 수집하되 메뉴는 추가하지않았습니다.
    '''

    try:
        with open('restaurant_bigdata.csv', 'r', encoding='UTF-8') as f:
            menudata = []
            while True:
                data = f.readline()
                if not data:
                    break
                menudata.append(data.split(','))

    except FileNotFoundError:
        pass

    menu = int(input('''
        1. 정보 입력
        2. 정보 출력
        3. 최근 정보 삭제
        0. 종료
        select menu : 
    '''))

    while menu != 0:

        if menu == 1:
            name = input('Input your name : ')
            restaurant_name = input('Input rastaurant name : ')
            if restaurant_name == '집밥' or restaurant_name == '코핫':
                Menu = input('Input Menu: ')
            else:
                Menu = ' '

            if Menu in jibbob_dict or Menu in cohot_dict or (not restaurant_name == '집밥' and not restaurant_name == '코핫'):
                if restaurant_name == '집밥':
                    price = jibbob_dict[Menu]
                elif restaurant_name == '코핫':
                    price = cohot_dict[Menu]
                else:
                    price = 0
            else:
                print("메뉴이름을 확인하세요.")
                Menu = input('Input Menu: ')
                while True:
                    if Menu in jibbob_dict or Menu in cohot_dict:
                        if restaurant_name == '집밥':
                            price = jibbob_dict[Menu]
                            break
                        elif restaurant_name == '코핫':
                            price = cohot_dict[Menu]
                            break
                        else:
                            price = 0
                            break
                    print("메뉴이름을 확인하세요.")
                    Menu = input('Input Menu: ')

            try:
               id = int(menudata2[-1][0].replace('\n','')) + 1
            except UnboundLocalError:
               id = int(menudata[-1][0].replace('\n','')) + 1

            with open('restaurant_bigdata.csv', 'a', encoding='UTF-8') as f:
                    f.write(str(id)+ ',')
                    f.write(name + ',')
                    f.write(restaurant_name + ',')
                    f.write(Menu + ',')
                    f.write('{0}\n'.format(price))
            with open('restaurant_bigdata.csv', 'r', encoding='UTF-8') as f:
                menudata2 = []
                while True:
                    data = f.readline()
                    if not data:
                        break
                    menudata2.append(data.split(','))




            menu = int(input('''
                1. 정보 입력
                2. 정보 출력
                3. 최근 정보 삭제
                0. 종료
                select menu : 
            '''))


        elif menu == 2:
            with open('restaurant_bigdata.csv', 'r', encoding='UTF-8') as f:
                menudata2 = []
                while True:
                    data = f.readline()
                    if not data:
                        break
                    menudata2.append(data.split(','))
                for i in range(len(menudata2)):
                    print('\t {0:8} {1:<12} {2:<15} {3:<8} {4:>10} \t'.format(menudata2[i][0],menudata2[i][1],menudata2[i][2],menudata2[i][3],menudata2[i][4]))


            menu = int(input('''
    1. 정보 입력
    2. 정보 출력
    3. 최근 정보 삭제
    0. 종료
    select menu : 
'''))

        elif menu == 3:
            with open('restaurant_bigdata.csv', 'r', encoding='UTF-8') as f:
                menudata2 = []
                while True:
                    data = f.readline()
                    if not data:
                        break
                    menudata2.append(data.split(','))
                print('\t {0:8} {1:<12} {2:<15} {3:<8} {4:>10} \t'.format(menudata2[-1][0], menudata2[-1][1],
                                                                              menudata2[-1][2], menudata2[-1][3],
                                                                              menudata2[-1][4]))
                op = input('가장 최근에 입력된 줄입니다. 정말 삭제합니까?(1:예, 2:아니오)')
                if op == '1' or op == '예':
                    del menudata2[-1]
                    f = open('restaurant_bigdata.csv', 'w', encoding='UTF-8')
                    for i in range(len(menudata2)):
                        f.write(menudata2[i][0] + ',')
                        f.write(menudata2[i][1] + ',')
                        f.write(menudata2[i][2] + ',')
                        f.write(menudata2[i][3] + ',')
                        f.write('{0}'.format(menudata2[i][4]))
                    f.close()
                    print('삭제가 완료되었습니다.')
                else:
                    pass

            menu = int(input('''
                           1. 정보 입력
                           2. 정보 출력
                           3. 최근 정보 삭제
                           0. 종료
                           select menu : 
                       '''))


        else:
            print('메뉴에 있는 번호를 입력해주세요.')
            menu = int(input('''
                1. 정보 입력
                2. 정보 출력
                3. 최근 정보 삭제
                0. 종료
                select menu : 
            '''))
    try:
        return menudata2
    except NameError:
        return menudata








if __name__ == '__main__':
    k = Sales()
    print(k)


























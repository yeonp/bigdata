from datetime import datetime
import os
class Time_set:
    def set_time(self):
        f0 = open("student.txt", "r", encoding="UTF-8")
        while True:
            name_ad = f0.readline()
            if not name_ad:break
            name = name_ad[0:-1]
            f = open(name + ".txt","r",encoding="UTF-8")
            f2 = open(name + "_temp.txt","w",encoding="UTF-8")
            f2.write(f.readline())
            while True:
                line = f.readline()
                if not line:break
                lines = line.split(" ")
                time1 = datetime(int(lines[0]),int(lines[1]),int(lines[2]),int(lines[4][0:2]),int(lines[4][3:5]),int(lines[4][6:8]))
                time2 = datetime(int(lines[0]),int(lines[1]),int(lines[2]),int(lines[5][0:2]),int(lines[5][3:5]),int(lines[5][6:8]))
                time = time2-time1
                f2.write(line[0:-1] + " " + str(time) + "\n")
            f.close()
            f2.close()
            os.remove(name+".txt")
            os.rename(name+"_temp.txt",name+".txt")
        f0.close()

if __name__ == "__main__":
    a = Time_set()
    while True:
        name = input("학생이름(end(종료) : ")
        if name == 'end':
            break
        a.set_time(name)
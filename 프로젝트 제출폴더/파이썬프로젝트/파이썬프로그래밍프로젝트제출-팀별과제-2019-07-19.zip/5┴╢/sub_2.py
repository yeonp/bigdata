# sub_2.py   출결미달자관리   이름, 출석일수/총출석일수,상태

class Attendance:
    def name(self):
        f = open("student.txt","r",encoding="UTF-8")
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
        print('이름','\t','출석일수','\t','상태')
        while True:
            check = 0
            line = f.readline()
            if not line: break
            f2 = open(line[0:-1] + ".txt", "r", encoding="UTF-8")    # 각각의 이름뒤에 엔터키가 있으니 -1 해줘야 이름들이 정상적으로 출력된다
            f2.readline()        # readline은 한줄씩 읽는건데, 이 줄은 header없애는거라 while아래에 쓰면 한줄 지우고 한줄 읽고 반복하기 때문에, while위에 써줘야한다
            while True:
                line1 = f2.readline()
                row_1 = line1.split(" ")
                if not line1: break
                check = check +1
                state = 0
                if 15 < check <= 20:
                    state = "주의"
                elif check <=15:
                    state = "퇴출"
                else:
                    state = "정상"
            if state !="정상":
                print(line[0:-1],'\t',check, "/25",'\t',state)
        input("enter를 누르면 다음 화면으로 이동합니다.")

if __name__ == "__main__":
    b = Attendance()
    b.name()

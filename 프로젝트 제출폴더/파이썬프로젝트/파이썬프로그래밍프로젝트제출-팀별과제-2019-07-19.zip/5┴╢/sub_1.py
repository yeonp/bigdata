# sub_1.py   종합출결현황    이름, 출석일수, 결석수, 시간
import datetime

class Total:
    def info(self):
        f = open("student.txt","r",encoding="UTF-8")
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
        print('이름', '출석일수', '결석일수', '총 이수시간')
        while True:
            line = f.readline()
            if not line: break
            f1 = open(line[0:-1] + ".txt", "r", encoding="UTF-8")    # 각각의 이름뒤에 엔터키가 있으니 -1 해줘야 이름들이 정상적으로 출력된다
            m = 0
            h = 0
            s = 0
            check = 0
            f1.readline()        # readline은 한줄씩 읽는건데, 이 줄은 header없애는거라 while아래에 쓰면 한줄 지우고 한줄 읽고 반복하기 때문에, while위에 써줘야한다
            while True:
                line_1 = f1.readline()
                if not line_1: break
                row_1 = line_1.split(" ")
                h = h + int(row_1[6][0:1])
                m = m + int(row_1[6][2:4])
                s = s + int(row_1[6][5:7])
                check = check + 1
            s = s % 60
            m = m + s // 60
            h = h + m // 60
            m = m % 60
            print(line[0:-1],' ',check,'\t ',25-check,'   ', str(h) + ':'+ str(m)+':'+ str(s))    # 각각의 이름뒤에 엔터키가 있으니 -1 해줘야 이름들이 정상적으로 출력된다
        input("enter를 누르면 다음 화면으로 이동합니다.")

if __name__ == "__main__":

    a = Total()
    a.info()

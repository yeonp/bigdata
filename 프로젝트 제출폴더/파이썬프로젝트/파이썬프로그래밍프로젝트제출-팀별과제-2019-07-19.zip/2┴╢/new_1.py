

import class_FB as FB

a = FB.Prepare_M()

b = FB.Play_1()

c= FB.jamjam()

b.rps_p()

print('\n')
print('\n')

p = input('IN TO THE GAME = ENTER')

a.fd_ab()

R = input('IN TO THE GAME = ENTER')

a.gk_ab()

c.jamjam2()

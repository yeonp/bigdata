library(rJava)      # 자바 지원
library(xlsx)       # 엑셀 파일 읽고 쓰고 저장하기
library(readxl)     # 엑셀 파일 불러오기
library(ggplot2)    # 시각화
library(dplyr)      # 전처리
library(foreign)    # SPSS 파일 불러오기
library(XML)

# 
crime16 <- read.csv("2016년_범죄발생지.csv", stringsAsFactors = FALSE)


# 필요없는 데이터 제외하고 필요한 데이터만 추출하기
crime16 <- crime16 %>% 
    filter(!범죄대분류 %in% c("지능범죄", "선거범죄", "병역범죄", "기타범죄"))
# 범죄 대분류에 4가지를 제외하면 총 12개가 사라진 26개가 남는 것을 확인 할 수 있다.


# 1. 강력범죄

# 강력범죄의 지역별 평균을 구하기 위해 강력범죄만 따로 추출한다.
test <- crime16 %>% 
    filter(범죄대분류 == "강력범죄")

str(crime16$범죄대분류)

# 너무 긴 이름을 간략하게 변경
test <- rename(test, 
               범죄 = 범죄대분류)

str(test)
# 필요없는 데이터 삭제
test$범죄중분류 <- NULL
test$계 <- NULL



str(test)
# 데이터 값의 울산만 int가 아닌 chr로 되어 있어 따로 추출하여 변경해준다.
울산 <- as.integer(test$울산)  
test$울산 <- NULL       # chr로 만들어진 울산을 삭제.
test <- cbind(test, 울산, stringsAsFactors = FALSE)

# 강력범죄에 대한 각 지역별 평균이 나온다.
test_1 <- test %>% 
    group_by(범죄) %>% 
    summarise(서울 = mean(서울),
                부산 = mean(부산),
                대전 = mean(대전),
                대구 = mean(대구),
                인천 = mean(인천),
                광주 = mean(광주),
                울산 = mean(울산)) 

# 2. 폭력 범죄
test <- crime16 %>% 
    filter(범죄대분류 == "폭력범죄")

test <- rename(test, 
               범죄 = 범죄대분류)

test$범죄중분류 <- NULL
test$계 <- NULL

str(test)

울산 <- as.integer(test$울산)  
test$울산 <- NULL       # chr로 만들어진 울산을 삭제.
test <- cbind(test, 울산, stringsAsFactors = FALSE)
str(test)

test_2 <- test %>% 
    group_by(범죄) %>% 
    summarise(서울 = mean(서울),
                부산 = mean(부산),
                대전 = mean(대전),
                대구 = mean(대구),
                인천 = mean(인천),
                광주 = mean(광주),
                울산 = mean(울산)) 


# 3. 절도 범죄 
test <- crime16 %>% 
    filter(범죄대분류 == "절도범죄")

test <- rename(test, 
               범죄 = 범죄대분류)

test$범죄중분류 <- NULL
test$계 <- NULL

str(test)

울산 <- as.integer(test$울산)  
test$울산 <- NULL       # chr로 만들어진 울산을 삭제.
test <- cbind(test, 울산, stringsAsFactors = FALSE)
str(test)

test_3 <- test %>% 
    group_by(범죄) %>% 
    summarise(서울 = mean(서울),
                부산 = mean(부산),
                대전 = mean(대전),
                대구 = mean(대구),
                인천 = mean(인천),
                광주 = mean(광주),
                울산 = mean(울산)) 

# 4. 풍속 범죄

test <- crime16 %>% 
    filter(범죄대분류 == "풍속범죄")

test <- rename(test, 
               범죄 = 범죄대분류)

test$범죄중분류 <- NULL
test$계 <- NULL

str(test)

울산 <- as.integer(test$울산)  
test$울산 <- NULL       # chr로 만들어진 울산을 삭제.
test <- cbind(test, 울산, stringsAsFactors = FALSE)
str(test)

test_4 <- test %>% 
    group_by(범죄) %>% 
    summarise(서울 = mean(서울),
                부산 = mean(부산),
                대전 = mean(대전),
                대구 = mean(대구),
                인천 = mean(인천),
                광주 = mean(광주),
                울산 = mean(울산)) 
# 5. 특별경제범죄
test <- crime16 %>% 
    filter(범죄대분류 == "특별경제범죄")

test <- rename(test, 
               범죄 = 범죄대분류)

test$범죄중분류 <- NULL
test$계 <- NULL

str(test)

울산 <- as.integer(test$울산)  
test$울산 <- NULL       # chr로 만들어진 울산을 삭제.
test <- cbind(test, 울산, stringsAsFactors = FALSE)
str(test)

test_5 <- test %>% 
    group_by(범죄) %>% 
    summarise(서울 = mean(서울),
                부산 = mean(부산),
                대전 = mean(대전),
                대구 = mean(대구),
                인천 = mean(인천),
                광주 = mean(광주),
                울산 = mean(울산)) 

# 6. 마약범죄
test <- crime16 %>% 
    filter(범죄대분류 == "마약범죄")

test <- rename(test, 
               범죄 = 범죄대분류)

test$범죄중분류 <- NULL
test$계 <- NULL

str(test)

울산 <- as.integer(test$울산)  
test$울산 <- NULL       # chr로 만들어진 울산을 삭제.
test <- cbind(test, 울산, stringsAsFactors = FALSE)
str(test)

test_6 <- test %>% 
    group_by(범죄) %>% 
    summarise(서울 = mean(서울),
                부산 = mean(부산),
                대전 = mean(대전),
                대구 = mean(대구),
                인천 = mean(인천),
                광주 = mean(광주),
                울산 = mean(울산)) 

# 7. 보건범죄
test <- crime16 %>% 
    filter(범죄대분류 == "보건범죄")

test <- rename(test, 
               범죄 = 범죄대분류)

test$범죄중분류 <- NULL
test$계 <- NULL

str(test)

울산 <- as.integer(test$울산)  
test$울산 <- NULL       # chr로 만들어진 울산을 삭제.
test <- cbind(test, 울산, stringsAsFactors = FALSE)
str(test)

test_7 <- test %>% 
    group_by(범죄) %>% 
    summarise(서울 = mean(서울),
                부산 = mean(부산),
                대전 = mean(대전),
                대구 = mean(대구),
                인천 = mean(인천),
                광주 = mean(광주),
                울산 = mean(울산)) 

# 8. 환경범죄
test <- crime16 %>% 
    filter(범죄대분류 == "환경범죄")

test <- rename(test, 
               범죄 = 범죄대분류)

test$범죄중분류 <- NULL
test$계 <- NULL

str(test)

울산 <- as.integer(test$울산)  
test$울산 <- NULL       # chr로 만들어진 울산을 삭제.
test <- cbind(test, 울산, stringsAsFactors = FALSE)
str(test)

test_8 <- test %>% 
    group_by(범죄) %>% 
    summarise(서울 = mean(서울),
                부산 = mean(부산),
                대전 = mean(대전),
                대구 = mean(대구),
                인천 = mean(인천),
                광주 = mean(광주),
                울산 = mean(울산)) 

# 9. 교통범죄
test <- crime16 %>% 
    filter(범죄대분류 == "교통범죄")

test <- rename(test, 
               범죄 = 범죄대분류)

test$범죄중분류 <- NULL
test$계 <- NULL

str(test)

울산 <- as.integer(test$울산)  
test$울산 <- NULL       # chr로 만들어진 울산을 삭제.
test <- cbind(test, 울산, stringsAsFactors = FALSE)
str(test)

test_9 <- test %>% 
    group_by(범죄) %>% 
    summarise(서울 = mean(서울),
                부산 = mean(부산),
                대전 = mean(대전),
                대구 = mean(대구),
                인천 = mean(인천),
                광주 = mean(광주),
                울산 = mean(울산)) 

# 10. 노동범죄
test <- crime16 %>% 
    filter(범죄대분류 == "노동범죄")

test <- rename(test, 
               범죄 = 범죄대분류)

test$범죄중분류 <- NULL
test$계 <- NULL

str(test)

울산 <- as.integer(test$울산)  
test$울산 <- NULL       # chr로 만들어진 울산을 삭제.
test <- cbind(test, 울산, stringsAsFactors = FALSE)
str(test)

test_10 <- test %>% 
    group_by(범죄) %>% 
    summarise(서울 = mean(서울),
                부산 = mean(부산),
                대전 = mean(대전),
                대구 = mean(대구),
                인천 = mean(인천),
                광주 = mean(광주),
                울산 = mean(울산)) 

# 11. 안보범죄
test <- crime16 %>% 
    filter(범죄대분류 == "안보범죄")

test <- rename(test, 
               범죄 = 범죄대분류)

test$범죄중분류 <- NULL
test$계 <- NULL

str(test)

울산 <- as.integer(test$울산)  
test$울산 <- NULL       # chr로 만들어진 울산을 삭제.
test <- cbind(test, 울산, stringsAsFactors = FALSE)
str(test)

test_11 <- test %>% 
    group_by(범죄) %>% 
    summarise(서울 = mean(서울),
                부산 = mean(부산),
                대전 = mean(대전),
                대구 = mean(대구),
                인천 = mean(인천),
                광주 = mean(광주),
                울산 = mean(울산)) 

# 각 범죄를 하나로 합하기
rm(crime_2016)
crime_2016 <- bind_rows(test_1, test_2, test_3, test_4, test_5, test_6, test_7,
                        test_8, test_9, test_10, test_11)


#그래프 만들기
go1 <- crime_2016 %>% select(범죄, 서울)
go1 <- rename(go1, 평균범죄건수 = 서울)
go11 <- go1 %>% mutate(지역 = "서울")

go2 <- crime_2016 %>% select(범죄, 부산)
go2 <- rename(go2, 평균범죄건수 = 부산)
go22 <- go2 %>% mutate(지역 = "부산")

go3 <- crime_2016 %>% select(범죄, 대전)
go3 <- rename(go3, 평균범죄건수 = 대전)
go33 <- go3 %>% mutate(지역 = "대전")

go4 <- crime_2016 %>% select(범죄, 대구)
go4 <- rename(go4, 평균범죄건수 = 대구)
go44 <- go4 %>% mutate(지역 = "대구")

go5 <- crime_2016 %>% select(범죄, 인천)
go5 <- rename(go5, 평균범죄건수 = 인천)
go55 <- go5 %>% mutate(지역 = "인천")

go6 <- crime_2016 %>% select(범죄, 광주)
go6 <- rename(go6, 평균범죄건수 = 광주)
go66 <- go6 %>% mutate(지역 = "광주")

go7 <- crime_2016 %>% select(범죄, 울산)
go7 <- rename(go7, 평균범죄건수 = 울산)
go77 <- go7 %>% mutate(지역 = "울산")

group_all16 <- bind_rows(go11, go22, go33, go44, go55, go66, go77)

View(group_all16)


ggplot(data = group_all16, aes(x= 지역, y= 평균범죄건수, fill = 범죄)) + geom_col(position = "dodge") + ggtitle("2016년 지역별 평균범죄건수") + theme(plot.title = element_text(size=30,vjust=2, color="black" )) + ylim(0, 75000)


seoul2015 <- read.csv("seoul2015.csv", stringsAsFactors = FALSE)
seoul2016 <- read.csv("seoul2016.csv", stringsAsFactors = FALSE)

group_seoul_all <- bind_rows(seoul2015, seoul2016)

ggplot(data = group_seoul_all, aes(x= 년도, y= 평균범죄건수, fill = 범죄)) + geom_col(position = "dodge") + ggtitle("서울 범죄건수") + theme(plot.title = element_text(size=30,vjust=2, color="black" )) + ylim(0, 75000) 

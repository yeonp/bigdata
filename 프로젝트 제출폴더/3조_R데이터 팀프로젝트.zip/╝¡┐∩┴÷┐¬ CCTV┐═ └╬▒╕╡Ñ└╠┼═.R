library(rJava)      # 자바 지원
library(xlsx)       # 엑셀 파일 읽고 쓰고 저장하기
library(readxl)     # 엑셀 파일 불러오기
library(ggplot2)    # 시각화
library(dplyr)      # 전처리
library(foreign)    # SPSS 파일 불러오기
library(XML)

# 
# 1. 서울 자치구 년도별 cctv 설치 현황
cctv <- read_excel("서울시 자치구 년도별 CCTV 설치 현황.xlsx")
cctv <- cctv %>% 
    select(기관명, `2015년`,`2016년`)
# 자치구와 15년 16년도만 남기고 삭제
str(cctv1)



# 2. 서울 자치구별 주민등록인구 
population <- read_excel("서울시 주민등록인구(구별)통계.xls")

# 필요한 데이터만 정제하기
# 기간과 자치구, 한국인과 외국인만 남기고 삭제
population <- population %>% 
    select(기간,자치구,인구...7,인구...10)

population <- rename(population,
                     한국인 = 인구...7,
                     외국인 = 인구...10)
str(population)

population <- population[-1,]
population <- population[-1,]

# 분기로 되어 있는걸 년으로 변경하여 정제하기

population$기간 <- ifelse(population$기간 < 2016, 2015,
                        ifelse(population$기간 <2017, 2016, NA))
as.ch
# 변수 타입 변경
population$한국인 <- as.numeric(population$한국인)  
population$외국인 <- as.numeric(population$외국인) 

# 이상치 제외하기
population <- population %>% 
    filter(!자치구 == "합계") %>% 
    group_by(기간, 자치구) %>%     
    summarise(한국인 = sum(한국인),
                 외국인 = sum(외국인)) 
# 2015년 정제
test1<- population %>%
    filter(기간 == 2015) %>% 
    group_by(기간, 자치구) %>%
    summarise(한국인 = sum(한국인),
                 외국인 = sum(외국인))
# 2016년 정제
test2<- population %>%
    filter(기간 == 2016) %>% 
    group_by(기간, 자치구) %>%
    summarise(한국인 = sum(한국인),
                 외국인 = sum(외국인))

population <- bind_rows(test1, test2)


# 3. cctv와 population 합치기

str(cctv)
str(population)

cctv <- rename(cctv,
               자치구 = 기관명)
table(cctv$자치구)

cctv1 <- cctv %>% 
    select(`2015년`,`2016년`)


str(cctv1)

cctv2 <- data.frame(기간 = c(2015),
                          자치구 = c("강남구", "강동구", "강북구", "강서구", 
                                  "관악구", "광진구", "구로구", "금천구", 
                                  "노원구", "도봉구", "동작구", "동대문구",
                                  "마포구", "서초구", "서대문구", "성동구", 
                                  "성북구", "송파구", "양천구", "영등포구", 
                                  "용산구", "은평구", "종로구" ,"중구", "중랑구"),
                      설치량 = c(760, 142, 147,	177, 593, 62, 256, 305, 461, 49, 111,
                              103, 164,	109, 624, 98, 263, 124, 178, 209, 76, 210, 163,	
                              191, 102),
                          stringsAsFactors = FALSE)
cctv3 <- data.frame(기간 = c(2016),
                      자치구 = c("강남구", "강동구", "강북구", "강서구", 
                              "관악구", "광진구", "구로구", "금천구", 
                              "노원구", "도봉구", "동작구", "동대문구",
                              "마포구", "서초구", "서대문구", "성동구", 
                              "성북구", "송파구", "양천구", "영등포구", 
                              "용산구", "은평구", "종로구" ,"중구", "중랑구"),
                      설치량 = c(770,240, 257, 168, 352, 19,326,109,298,102,233,
                              314,334,266,474,39,357,88,338,248,77,358,129,23,75),
                      stringsAsFactors = FALSE)

cctv4 <- bind_rows(cctv2, cctv3)

str(cctv4)
seoul <- left_join(population, cctv4)



# 한국인과 외국인 합하여 서울 거주 인구 구하기 
sam <- seoul %>% 
    group_by(한국인, 외국인) %>% 
    summarise(인구 = sum(한국인 + 외국인))

seoul <- left_join(seoul, sam)

# 기간 설정
seoul$기간 <- ifelse(seoul$기간 == 2015 , "2015년", "2016년")
qplot(seoul$기간)

# 15년도와 16년도 인구 변화 그래프
ggplot(data = seoul, aes(x = 자치구, y = 인구, fill = 기간)) +
    geom_col(position = "dodge")

# 15년도와 16년도 cctv 설치량 변화 그래프
ggplot(data = seoul, aes(x = 자치구, y = 설치량, fill = 기간)) +
    geom_col(position = "dodge")


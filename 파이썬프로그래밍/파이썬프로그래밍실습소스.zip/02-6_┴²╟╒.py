# 02-6_집합.py
# set, { } , mutable 자료형, 순서가 없다
# 중복허용하지 않는다

s = {1,2,3}
print(s,type(s))  # {1, 2, 3} <class 'set'>

s = {3,2,1}
print(s,type(s))  # {1, 2, 3} <class 'set'>

l = [1,2,2,3,3,4,4,5]  #중복허용
print(l)
print(len(l))  # 8

s= {1,2,2,3,3,4,4,5}  #중복 허용하지 않음
print(s)  # {1, 2, 3, 4, 5}
print(len(s))  # 5

s.add(6)      # 집합에 1개의 요소 추가
print(s)

s.update({7,8,9})  # 집합에 여러개의 요소를 추가
print(s)

s.remove(9)    # 특정 요소를 제거
print(s)

# 집합의 연산 : 합집합,교집합 차집합, 대칭 차집합
s1 = {1,2,3,4,5,6}
s2 = {5,6,7,8,9,10}

# 합집합 : '|', union()
s = s1 | s2
print(s)  # {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}

s = s1.union(s2)
print(s)  # {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}

# 교집합 : '&', intersection()
s = s1 & s2
print(s)    # {5, 6}

s = s1.intersection(s2)
print(s)    # {5, 6}

# 차집합 : '-', difference()
s = s1 - s2
print(s)    # {1, 2, 3, 4}

s = s1.difference(s2)
print(s)    # {1, 2, 3, 4}

# 대칭차집합
s = s1.symmetric_difference(s2)
print(s)    # {1, 2, 3, 4, 7, 8, 9, 10}

s = (s1- s2) | (s2 - s1)
print(s)    # {1, 2, 3, 4, 7, 8, 9, 10}

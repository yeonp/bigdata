# 02-2_문자열.py
"""
문자열 자료형 : 불변형 (immutable)
2019-07-02 Tue.
"""
a = "Python is Great!"
print(a)
b = 'Life is Short, You need Python'
print(b)
c = "He said 'I love you'"
print(c)
d = 'He said "I love you"'
print(d)

#d = "He said "I love you""  --> SyntaxError

f = '''
Hello
Python
'''
print(f)

f = """
Hello
Python3
"""
print(f)

# 문자열의 Indexing 과 Slicing

# 인덱싱
a = 'Life is too short, you need Python'  # 마지막 33

print(a[0],a[1],a[2],a[8],a[True],a[False])

#a[0] = 'l'  # 불변형 자료형이므로 요소 수정이 불가
#TypeError: 'str' object does not support item assignment

print(a[-1],a[-2],a[-3],a[-11]) # 뒤에서 부터 인덱싱

print(a[0] + a[1] + a[2] + a[3])

# 슬라이싱 : a[시작옵셋:(끝옵셋 +1) ]
print(a[0:3]) # From 0 to (3-1)
print(a[0:4]) # From 0 to (4-1)
print(a[0:11]) # From 0 to 10
print(a[:11]) # From 0 to 10

print(a[:]) # From 0 to 33
print(a[:-1]) # From 0 to 32

print(a[12:17]) # "short"
print(a[12:])   # "short, you need Python"
print(a[12:34]) # "short, you need Python"
print(a[12:-1]) # "short, you need Pytho"
print(a[12:33]) # "short, you need Pytho"

print(a[-11:-7]) # "need"

# a[시작옵셋:(끝옵셋 +1):간격(step) ]
print(a[0:30:3])
print(a[::2])
print(a[::-1]) # nohtyP deen uoy ,trohs oot si efiL

a = "20010331Rainy"
date = a[:8]
weather = a[8:]

print(date)
print(weather)

a = "20010331Rainy"
year = a[:4]
date = a[4:8]
weather = a[8:]

print(year)
print(date)
print(weather)

a = "Pithon"
#a[1] = 'y'

b = a[:1] + 'y' + a[2:]
print(b)


# 문자열 연산 : <class 'str'> 의 method(메서드)
s1 = 'first'
s2 = 'second'
s3 = s1 + s2
print(s3)

print(len(s3)) # 문자열의 사이즈

a = "i like programming. i like swimming"
print(type(a)) #  <class 'str'>

b = a.upper() # 대문자로 변환
print(b)
print(a)      # 원본은 그대로 유지
c = b.lower() # 소문자로 변환
print(c)
d = c.title() # 단어의 첫글자만 대문자로 변환
print(d)

num = a.count('like')  # 문자의 사용횟수
print(num)   # 2

num = a.find('like')   # 문자의 위치 인덱스값을 반환
print(num)   # 2

num = a.find('hello')   # 없으면  -1을 반환
print(num)   # -1

num = a.find('like',3)   # 검색 시작위치를 3으로 지정
print(num)   # 22

num = a.rfind('like')   # 역순 검색, 뒤에서 부터 검색
print(num)   # 22

num = a.index('like')   # 위치를 반환
print(num)   # 2

# num = a.index('hello')   # 위치를 반환  ValueError!

b = a.startswith('i like')   # 'i like'로 시작하는 문자열인가?
print(b)   # True

a = ' spam and ham '
print(a)
s = a.strip()  # 좌우 공백 제거
print(s)

s = a.lstrip()  # 왼쪽 공백 제거
print(s)

s = a.rstrip()  # 오른쪽 공백 제거
print(s)

s1 = a.split()  #  공백으로 분리하고 리스트로 반환
print(s1)    # ['spam', 'and', 'ham']

s = a.split('and')  #  and로 분리하고 리스트로 반환
print(s)    # ['spam','ham']


s2 = ':'.join(s1)  # 문자를 삽입
print(s2)     # spam:and:ham

a = 'abcdefg'
s2 = ':'.join(a)
print(s2)      # a:b:c:d:e:f:g

a = 'Life is too short'
b = a.replace('Life','Your leg' )
print(b)

# eval():문자열로 표현된 식(expression)을 파이선 인터프리터가
#        번역하여 실행시킨다

a = 10
b = 20
#c = a + b
c = eval('a + b')
print(c)

# velocity = input( 'Input velocity : ' )
# distance = input( 'Input distance : ' )

# time = eval( distance + '/' + velocity )
# print(time)


# byte : 0~255(0xFF)
a = b"Python rules"     # <class 'bytes'>
print(a,type(a))
s = a.decode('utf-8')   # <class 'str'>
print(s,type(s))        # Python rules
b2= s.encode('utf-8')   # <class 'str'>
print(b2,type(b2))      # b'Python rules'

# maketrans()/translate()함수 :
# 문자열을 mapping하여 변환한 결과를 얻을 수 있다

a = 'ㄱㄴㄷㄹㅁㅂㅅㅇㅈㅊㅋㅌㅍㅎ'
b = 'ㅏㅔㅣㅗㅜ'
c = 'gndrmbsojcktph'
d = 'aeiou'
kor = a + b
eng = c + d

transtable = ''.maketrans(kor,eng)
print(type(transtable))  # <class 'dict'>

result = 'ㄱㅏㄴㅣㅂㅏㅂㅗ'.translate(transtable)
print(result)
print(len(a),len(b))

a = "Hello"
print(a*5)  # HelloHelloHelloHelloHello


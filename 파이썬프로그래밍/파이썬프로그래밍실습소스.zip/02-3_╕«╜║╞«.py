# 02-3_리스트.py

# List : mutable 자료형, 시퀀스(순서형), 가장 유용한 자료형
# []:대괄호 사용

a =  [1,2,3,4,5,6,7,8,9]

print(a)
print(type(a))   # <class 'list'>

# 인덱싱
print(a[0],a[1],a[2],a[8])
print(a[-1],a[-2],a[-3],a[-4])
a[0] = 10    # mutale 자료형이므로 요소의 변경이 가능하다
print(a)
a[0] = 1
print(a)

# 슬라이싱 : a[시작옵셋:(끝옵셋 +1) ]
print(a[1:5])
print(a[1:])
print(a[:5])
print(a[:-1])

a[1:5] = [20,30,40,50]
print(a)
a[1:5] = [2,3,4,5]

# a[시작옵셋:(끝옵셋 +1):간격(step) ]
print(a[0:8:2])   # 홀수만 출력 [1, 3, 5, 7]
print(a[0:8:-1])  # []
print(a[::-1])    # [9, 8, 7, 6, 5, 4, 3, 2, 1]
print(a[8::-1])   # [9, 8, 7, 6, 5, 4, 3, 2, 1]
print(a[8:0:-1])  # [9, 8, 7, 6, 5, 4, 3, 2]

a[::2] = [10,30,50,70,90]
print(a)
a[::2] = [1,3,5,7,9]

l = list(range(10))
print(l)   # [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

l = list(range(1,10))
print(l)   # [1, 2, 3, 4, 5, 6, 7, 8, 9]

l = list(range(1,10,2))
print(l)   # [1, 3, 5, 7, 9]

# sum()함수 : 시퀀스형 데이터의 총합을 구한다
a =  [1,2,3,4,5,6,7,8,9]
print(sum(a))
print(max(a))
print(min(a))

# LIST 연산
a = [1,2,3]
b = [3,4,5]
c = a + b
print(c)    # 합연산, [1, 2, 3, 3, 4, 5]
d = a * 3
print(d)    # 반복 연산, [1, 2, 3, 1, 2, 3, 1, 2, 3]

print(len(a)) # 3

print( 3 in a) # True
print( 0 in a) # False

del b[0]    # [4, 5]   , 객체를 삭제
print(b)

# 추가 제거
ret = a.append(4)
print(a)   # [1, 2, 3, 4]
print(ret) # None
a.append([5,6])  # [1, 2, 3, 4, [5, 6]]
print(a)
a.insert(1,1.5)  # insert(인덱스,데이터)
print(a)   #  [1, 1.5, 2, 3, 4, [5, 6]]
a.remove(1.5)
print(a)
a.remove([5, 6])
print(a)
a.pop()   # List의 마지막 요소를 제거
print(a)  #  [1, 2, 3]
a.pop(1)   # List의 해당 인덱스의 요소를 제거
print(a)  #  [1, 3]


# 정렬
a = [1,5,2,4,3]
a.sort()   # 정렬(오름차순)
print(a)   # [1, 2, 3, 4, 5]

a.sort(reverse = True)   # 역순으로 정렬(내림차순)
print(a)   # [5, 4, 3, 2, 1]

a = [1, 2, 3, 4, 5]
print(a.index(3))   # 2
#print(a.index(7))   # ValueError: 7 is not in list
a.append(5)
print(a.count(5))  # 2
a.pop()
a.reverse()   # 순서를 반대로
print(a)      # [5, 4, 3, 2, 1]

a = [1,2,3]
b = [4,5,6]
a.extend(b)   # a = a + b
print(a)      # [1, 2, 3, 4, 5, 6]

# 확장슬라이싱: 시작과 끝값이 없고 step값 만 지정
c = [0,1,2,3,4,5,6,7,8,9,10]
print(c[::2])  # [0, 2, 4, 6, 8, 10]

# 중첩(Nested) 리스트 : 리스트안에 또 다른 리스트가 포함
a = [1,2,3,4,[5,6,7]]   # 2중 리스트
print(a[4])    # [5, 6, 7]
print(a[4][1]) # 6

a = [1,2,3,4,[5,6,7,[8,9,10]]]   # 3중 리스트
print(a[4])        # [5, 6, 7, [8, 9, 10]]
print(a[4][3])     # [8, 9, 10]
print(a[4][3][1])  #  9

a = [7,8,9]
b = [4,5,6,a]   # [4, 5, 6, [7, 8, 9]]
c = [1,2,3,b]   # [1, 2, 3, [4, 5, 6, [7, 8, 9]]]
print(b)
print(c)
a = [10,11,12]
print(b)
print(c)  #    [1, 2, 3, [4, 5, 6, [7, 8, 9]]]


a = [7,8,9]
b = [4,5,6,a]   # [4, 5, 6, [7, 8, 9]]
c = [1,2,3,b]   # [1, 2, 3, [4, 5, 6, [7, 8, 9]]]
a[0] = 10
print(b)
print(c) #  [1, 2, 3, [4, 5, 6, [10, 8, 9]]]

# 리스트 내장(list Comprehension)
a = [k for k in range(10)]
print(a) # [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

a = [1,2,3,4,5,6,7]
b = [k for k in a if k > 4]
print(b) #  [5, 6, 7]

c = [k for k in a if k % 3 == 0]
print(c) # [3, 6]

d = [k for k in a if k % 3 != 0 ]
print(d) # [1, 2, 4, 5, 7]


# 리스트 내장을 이용한 데이터의 조합 리스트 생성
seq1 = 'abc'   # 문자열
seq2 = (1,2,3) # 튜플

l = [ (x,y) for x in seq1 for y in seq2]
print(l)
# [('a', 1), ('a', 2), ('a', 3),
# ('b', 1), ('b', 2), ('b', 3),
# ('c', 1), ('c', 2), ('c', 3)]


# for 문

total = 0
# for k in range(11): # From 0 to 10 , step = 1
# for k in range(1,11): # From 1 to 10 , step = 1
# for k in range(1,11,2): # From 0 to 10 , step = 2

for k in range(1,11,2):
    print(k)
    total = total + k
print('total:',total)

a = [10,20,30,40,50,60,70,80,90]
print(a[0],a[2],a[4],a[6],a[8])  # 10 30 50 70 90
print(a[::2])                    # [10, 30, 50, 70, 90]

for k in range(9):
    print(a[k], end =' ') # 10 20 30 40 50 60 70 80 90

print()
for k in range(0,9,2):
    print(a[k], end =' ') # 10 30 50 70 90
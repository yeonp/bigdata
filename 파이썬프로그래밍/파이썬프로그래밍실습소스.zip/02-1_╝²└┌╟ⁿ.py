# 02-1_숫자형.py

# 표준 입출력

# 표준 입력 : 변수 = input("문자열")

# a = input()
# print(a)

# math = input("수학점수:")     # 문자열 타입을 반환
# english = input("영어점수:")  # 문자열 타입을 반환
# total = int(math) + int(english)  # 문자열을 숫자로 형변환
# print('총점:',total)

# 표준 출력 : print()

print('add : ', 4 + 5, 'sub = ', 4 - 2)  # 마지막에 \n
print(1,2);print(3,4)   # 마지막에 자동으로  \n
print(1,2, end = ' ')    # 마지막에 \n 대신 Space로 출력
print(5,6,7)            # ,사이 문자를 빈칸으로 구분하여 출력
print(5,6,7, sep = ':') # ,사이 문자를 ':'으로 구분하여 출력

# print() formatting
num_1 = 10       # int 형
num_2 = 1.234    # float 형
str_1 = "Hello Python"
print("int형:%d"%num_1)   # %d int형
print("float형:%f"%num_2) # %f float형
print("16진수:0x%x"%num_1)# %x 16진수
print("8진수:%o"%num_1)   # %o 8진수
print("문자열:%s"%str_1)  # %s 문자열
print("문자열:%s"%num_2)  # %s 문자열
#print("int형:%d"%str_1)   # %d int형 ==> 문법오류(Type Error!)
print("문자열:%s int형:%d"%(str_1,num_1))  # %s 문자열

# format()함수 사용
print( format(1.234567,"7.6f")) # 전체 7자리 ,소숫점 6자리

print('{0} {1}'.format('apple',7.77))

print('{0:<10}{1:5.2f}'.format('apple',7.77))
print('{0:>10}{1:5.2f}'.format('apple',7.77))
print('{0:^10}{1:5.2f}'.format('apple',7.77))
print('{0:=<10}{1:5.2f}'.format('apple',7.77))
print('{0:=>10}{1:5.2f}'.format('apple',7.77))
print('{0:=^10}{1:5.2f}'.format('apple',7.77))


# 숫자형 변수
a = 12345

# int형
print(int(a))
print(bin(15))  # 2진수
print(hex(15))  # 2진수
print(oct(15))  # 2진수

# float형 : 실수형
print(float(a))

# complex형 : 복소수형
print(complex(a))  # (12345+0j)

print(float('inf')) #무한대

num = float('inf')
print(num/1000)  # inf/정수 ==> inf
print(1000/num)  # 정수/inf ==> 0.0
print(num/num)  # inf/inf ==> nan , Not a Number
print(float('nan')) # ==> 'nan'


# 사칙연산 : +,-, *, /, %, //, **
a = 10
b = 3
c = a + b
d = a - b
e = a * b
f = a / b
print(f)  # 3.3333
g = a % b
print(g)  # 나머지 : 1
f2 = a // b
print(f2)  # 정수 몫: 3
h = a ** b # a의 b제곱
print(h)  # 10^3 --> 1000


#print("-"*50)

# bool : True는 1 False는 0 정수 값으로 간주된다

a = 1
print(a > 0)  # True
print(a < 0)  # False

b = a > 0
print(b)
print(type(b))
print(type(a))

c = True + True + b
print(c,type(c))

d = bool(3)    # True
print(d,type(d))

d = bool(-3)    # True
print(d,type(d))

d = bool(0)    # False
print(d,type(d))

d = bool([])   # False
print(d,type(d))

d = bool([0])  # True
print(d,type(d))

d = bool()  # False
print(d,type(d))
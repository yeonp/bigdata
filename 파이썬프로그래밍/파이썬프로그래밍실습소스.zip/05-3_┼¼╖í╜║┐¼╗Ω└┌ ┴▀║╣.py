# 05-3_클래스 연산자 중복.py

# 연산자 중복(Operator Overloading)
# 파이썬에 내장되어있는 연산자(메서드,함수)를
# 사용자 클래스내에서 재정의하여 사용

class Calculator:

    def __init__(self):
        print('Calcualtor 생성자')
        self.a = 20
        self.b = 30
        self.info_str = 'Calcualtor class v1.0'

    def add(self,a,b):
        return a + b

    def subtract(self,a,b):
        return a - b

    def __add__(self,instance2):
        print('연산자 중복:__add__')
        result1 = abs(self.a) + abs(instance2.b)
        result2 = str(self.a) + str(instance2.b)
        return result2,result1

    #   __str__는  __repr__를 메서드를 대신할수 없다
    def __str__(self):
        print('연산자 중복:__str__')
        return self.info_str

    #  __repr__는 __str__ 메서드를 대신할수 있다
    def __repr__(self):
        print('연산자 중복:__repr__')
        return self.info_str

cal = Calculator()
cal2= Calculator()
cal.a = 300
cal2.b = -500
# print(cal.add(10,20))
result = cal + cal2
print(result)

print(str(cal))
print(repr(cal))

# # <class int>
# a = 20
# b = 60
# c = a + b
# c = a.__add__(b)   #  '+' ==> '__add__()'
# print(c)
#
# # <class str>
# a = 'Hi'
# b = 'Bye'
# c = a + b
# c = a.__add__(b)   #  '+' ==> '__add__()'
# exception.py
# 파일읽기 시도 시 파일이 없어서 오류 날때 예외처리 코드
try:
    with open('hello.txt', 'r') as f:
        while True:
            data = f.readline()
            if not data:
                break
except FileNotFoundError:
    print("파일이 없어요")
    pass

print('정상 처리 종료')

print(FileNotFoundError)
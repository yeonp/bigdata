# class_human.py

# 1. class 를 정의
# 2. 클래스 멤버를 정의(옵션)
# 3. 생성자를 구현
# 4. 인스턴스 멤버를 정의
# 5. 메서드를 구현
# 6. 소멸자는 생략해도 된다
# 7. 클래스의 인스턴스 객체를 만들고 메서드를 호출해본다
# 8. 모듈로 제공하기 위한 처리( if __name__ == '__main__':)

# 1. class 를 정의
class Human:

    # 2. 클래스 멤버를 정의(옵션)
    life = False
    eyes = 2

    # 3. 생성자를 구현
    def __init__(self,name ='무명',gender='미결정'):
        print('생성자')

        # 4. 인스턴스 멤버를 정의
        # 인스턴스 멤버 : self.변수명 = <값>
        self.name = name
        self.age = 1
        self.gender = gender  # '남성','여성'
        self.height = 1
        self.phone_number = '000-0000-0000'
        self.fat_ratio = 0
        Human.life = True

    # 5. 메서드를 구현
    def set_name(self,name):  # 이름을 변경
        self.name = name

    def get_name(self):       # 이름을 반환
        return self.name

    def set_age(self,age):    # 나이를 변경
        self.age = age

    def get_age(self):        # 나이를 반환
        return self.age

    def set_age_one_year(self): # 나이를 1살 증가
        self.age = self.age + 1

    def set_height(self,height):  # 키(신장)를 변경
        self.height = height

    def get_height(self):        # 키(신장)를 반환
        return self.height


    # 미니과제 :  인스턴스멤버로 fat_ratio를 추가하고 초기값은 0
    # 표준체중(kg) = (신장(cm) - 100)×0.85
    # 비만도( %)=현재체중 / 표준체중( %)×100
    def set_weight(self,weight):
        self.weight = weight

    def get_fat_ratio(self):
        standard_weight = (self.height - 100)*0.85
        self.fat_ratio = (self.weight/standard_weight)*100
        return self.fat_ratio

    def set_phone_number(self,phone): # 전화번호 변경
        self.phone_number = phone

    def get_phone_number(self):   # 전화번호 반환
        return self.phone_number

    def get_birth_year(self,current_year): # 출생연도를 반환
        return current_year - self.age + 1

    # def __del__(self):  # 인스턴스객체 소멸시 자동으로 호출
    #     print('소멸자') # 파이썬에서는 소멸자를 흔히 생략한다

# 7. 클래스의 인스턴스 객체를 만들고 메서드를 호출해본다
# 8. 모듈로 제공하기 위한 처리( if __name__ == '__main__':)

if __name__ == '__main__':
    nobody = Human() # 클래스의 인스턴스 객체 생성

    kildong = Human('홍길동','남성') # 클래스의 인스턴스 객체 생성

    print('name:', kildong.name)  # 인스턴스 멤버를 직접 접근
    print('name:', kildong.get_name()) # 메서드를 호출

    kildong.set_age(25)
    print('age:', kildong.age)  # 인스턴스 멤버를 직접 접근
    print('age:', kildong.get_age()) # 메서드를 호출

    current_year = 2019
    print(kildong.get_birth_year(current_year)) # 1995

    # 미니과제 :  인스턴스멤버로 fat_ratio를 추가하고 초기값은 0
    # 표준체중(kg) = (신장(cm) - 100)×0.85
    # 비만도( %)=현재체중 / 표준체중( %)×100
    kildong.set_weight(60)
    kildong.set_height(170)
    print('[',kildong.name,']','의 비만도: [{:5.2f}]%'.format(kildong.get_fat_ratio()))

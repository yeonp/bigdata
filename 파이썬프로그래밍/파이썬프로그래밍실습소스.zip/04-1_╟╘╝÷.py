# 04-1_함수.py
'''
def 함수명(매개변수):
    <수행할 문장1>
    <수행할 문장2>
    ...
    return 반환할값
'''
def add_one_and_ten_time():
# def not_used():

    # 1회 덧셈
    a = 10
    b = 20
    c = a + b
    print('a + b = %d'%c)

    # 10회 덧셈을 반복
    a = [1,2,3,4,5,6,7,8,9,10]
    b = [10,20,30,40,50,60,70,80,90,100]
    for k in range(len(a)):
        print(k,':',a[k] + b[k])

    print()
    #함수 구현

# add()함수 정의
def add(a,b):
    c = a + b
    print('add called!!')
    return c

print(add(5,4))
print(add('Hello','Good Bye'))
print(add([1,2,3],[4,5,6]))
print(add((1,2,3),(4,5,6)))


# subtract()함수 정의
def subtract(a,b):
    c = a - b
    print('subtract called!!')
    return c

# multiply()함수 정의
def multiply(a,b):
    c = a * b
    print('multiply called!!')
    return c

# divide() 함수 정의
def divide(a,b):
    c = a / b
    print('devide called!!')
    return c

# 함수 호출
result = add(10,20)
print(result)

result = subtract(10,20)
print(result)

result = multiply(10,20)
print(result)

result = divide(10,20)
print(result)

# 함수내에서 함수 호출하는 함수 구현

# myfunc(a,b,c,d,e) = ((a + b)*(c - d))/e
# 1 . 함수내에서 직접 연산
def myfunc1(a,b,c,d,e):
    if e == 0 :
        return "ZeroDivision!!"
    f = ((a + b)*(c - d))/e
    print('myfunc1 called!!')
    return f

# result = myfunc1(1,2,6,4,0)
# print(result)   # ZeroDivision!!
#
# result = myfunc1(10,20,60,40,10)
# print(result)   # 60.0

# 2. add/subtract/multiply/divide함수 사용
def myfunc2(a,b,c,d,e):
    if e == 0 :
        return "ZeroDivision!!"
    # f = ((a + b)*(c - d))/e
    f = divide(multiply(add(a,b),subtract(c,d)),e)
    print('myfunc2 called!!')
    return f
print('-'*50)
result = myfunc2(1,2,6,4,0)
print(result)   # ZeroDivision!!
print('-'*50)
result = myfunc2(10,20,60,40,10)
print(result)   # 60.0

# 함수 구현 순서
# (1) def 를 사용하고 함수이름을 결정
# (2) 매개변수(인자)를 결정
# (3) 인자를 사용하여 처리하는 코드를 구현
# (4) return을 사용하여 결과값을 반환
# (5) 인자를 설정하여 함수를 호출하여 결과를 확인

# 함수 유형 4가지
# [1] 반환값이 없고  매개변수(인자) 없고
def f_1():
    print('f_1 is called!!')

f_1()

# [2] 반환값이 없고  매개변수(인자) 있고
def f_2(a,b):
    print('f_2:',a,b,a+b,a-b,a*b,a/b)

f_2(12,34)

def f_22(a1 = 0,a2 = 0,a3 = 'None'): # a3 = 'None',기본인자
    print('f_22:',a1,a2,a3)
f_22()
f_22(1)
f_22(10,20)
f_22(10,20,30)
f_22("HELLO",(1,2,3,4),[5,6,7])

# [3] 반환값이 있고  매개변수(인자) 없고
def f_3():
    print('f_3 is called!!')
    return 'Bread','Butter',100

print(f_3())

# [4] 반환값이 있고  매개변수(인자) 있고
def f_4(a,b):
    print('f_4 is called!!')
    return a + b, a - b, a * b, a / b
print(f_4(3,5))

# 문제 : 2개의 정수에 대해 큰 수,작은 수의 순서로 반환
#       하는 함수를 만드세요 (함수 이름은 order())
# 3 5 ==> 5 3
# 5 3 ==> 5 3
def order(a,b):
    if a < b:
        a,b = b,a
    return a,b

print(order(3,5))    # 5 3
print(order(50,30))  # 50 30

# max(a,b) 함수 구현
def max(a,b):
    if a > b:
        return a
    return b
print(max(10,20))
print(max(30,10))

# min(a,b) 함수 구현
def min(a,b):
    if a < b:
        return a
    return b
print(min(10,20))
print(min(3,1))

# sum(리스트) 함수 구현
def sum(l):
    total = 0
    for k in l:
        total = total + k
    return total
print(sum([1,2,3,4,5,6,7,8,9,10]))
print(sum(list(range(100))))

# mean(리스트) 함수 구현
def mean_0(l):
    total = 0
    for k in l:
        total = total + k
    return total/len(l)

def mean(l):
    return sum(l)/len(l)

print(mean([1,2,3,4,5,6,7,8,9,10]))
print(mean(list(range(100))))

print('-'*50)
# 인수의 갯수가 고정되지 않은 인수 처리 방법
# (1) *변수 : tuple 형식
def add_many(a,b,*args):
    total = 0
    print(type(args))  # <class 'tuple'>
    for k in args:
        total = total + k
    return total
print(add_many(10,20,30,40,50,60,70,80,90,100))

# 키워드 인수(사전 사용)
# (2) **변수 : dict 형식
def func(width, height, **kw):
    print(width, height)
    print(type(kw),kw)   # <class 'dict'> {'depth': 5, 'dimension': 7}
func(width = 10,height = 20,depth = 5, dimension = 7)


# 함수 사용시 변수의 유효범위 규칙(Scope Rule)
# LEGB 규칙 : Local > Enclosing Function Local
#             > Global  >  Built-in
x = 10    # G:전역변수(Global Variable)
y = 11    # G:전역변수(Global Variable)

def foo():
    x = 20 # L: 지역변수(Local Variable)
    foo_list = [1,2]   # L: 지역변수(Local Variable)
    print('foo:',x)  # foo: 20
    def bar():
        a = 30 # # L: 지역변수(Local Variable)
        print('bar:',a,x,y) # a:L , x:E , y:
          # bar: 30 20 11

    bar()

foo()
print('Global:',x)

# 주의해야할 변수 사용
# def foo2():
#     foo_list[0] = 10  # 오류


# 일급 함수(First Calss function)
# (1)함수객체를 다른 함수의 인수로 전달할 수 있다
# (2)함수객체를 반환 값으로 전달할 수 있다
# (3)함수객체를 다른 자료구조에 저장해서 사용 가능
def add_two(a,b):
    print('add_two is called')
    return a + b

def func_two(func,a,b):
    print('func_two is called')
    result = func(a,b)
    return result

result = func_two(add_two,10,20) # 함수를 인자로 전달
print(result)

def foo2():
    print('foot2 is called!!')
    def bar2():
        print('bar2 is called!!')
    return bar2   # 함수 객체를 반환
result = foo2()
print(type(result)) # <class 'function'>

result()   # bar2 is called!!  bar2()함수 호출

# 함수를 자료구조에 저장
func_list = [add,subtract,multiply,divide]
result = func_list[0](10,50)   # add(10,50)
print(result)
result = func_list[1](10,50)   # subtract(10,50)
print(result)

a = add
a(1,2)
b = a
b(3,4)

# 람다(lambda)함수 : 한줄짜리 함수식
# 식을 정의하는 순간 바로 함수 객체로 사용, 바로 인수로
# 전달할 수 있다
# def add_new(a,b):  # 일반 함수
#     return a + b

#  함수명 = lambda <인수1>,<인수2>,... : <반환할 식>
add_new = lambda a,b: a + b
result = add_new(7,10)
print(result)

def f1(x):
    return x*x + 1

def g(func):
    return [func(x) for x in range(1,5)]

print([f1(x) for x in range(1,5)])
print([f1(1),f1(2),f1(3),f1(4)])
print(g(f1))

print(g(lambda x : x*x + 1))  # 람다함수 사용
print(g(lambda x : x*x*x + x*x + 1))  # 람다함수 사용

# 파이썬 내장(Built-in) 함수
# map() 함수
def multi_two(x):
    return x*2

result = map(multi_two,[1,2,3,4,5])
print(list(result))

# abs() :절대값을 구해주는 함수
print(abs(-1234))  # |-1234| --> 1234
print(abs(1234))  # |1234| --> 1234
print(abs(0))  # |0| --> 0

# chr(수) : 아스키 코드 문자를 출력
print(chr(97)) # --> 'a'
print(chr(48)) # --> '0'

# 1 ~ 255 까지 아스키 코드값과 해당 문자가 출력
# 97:a
# 98:b
for k in range(1,255):
    print(k,':',chr(k),end=' , ')
    if k%5 == 0:
        print()
print()
# ord() : 문자의 아스키 값을 반환
print(ord('a'))  # 97
# max()/min()/sum()/round()/pow()
# id() : 객체의 참조 주소 값을 반환
# hex() : 16진수로 변환
# zip() : 2개이상의 시퀀스자료형을 서로 묶어서 반환
print(list(zip([1,2,3],[5,6,7])))
# [(1, 5), (2, 6), (3, 7)]
print(list(zip([1,2,3],['a','b','c'],[5,6,7])))
# [(1, 'a', 5), (2, 'b', 6), (3, 'c', 7)]

# globals()/locals() :전역/지역 심볼테이블을 얻는다
print(globals())
# {'__name__': '__main__', '__doc__': '\ndef 함수명(매개변수)
# :\n    <수행할 문장1>\n    <수행할 문장2>\n    ...\n
# return 반환할값\n', '__package__': None,
# '__loader__': <_frozen_importlib_external.
# SourceFileLoader object at 0x000002437F1A7390>, '__spec__': None, '__annotations__': {}, '__builtins__': <module 'builtins' (built-in)>, '__file__': 'C:/Users/CPB02GameN/PycharmProjects/Test01/04-1_함수.py', '__cached__': None, 'add_one_and_ten_time': <function add_one_and_ten_time at 0x000002437F36ABF8>, 'add': <function add at 0x000002437F36AEA0>, 'subtract': <function subtract at 0x000002437F36AF28>, 'multiply': <function multiply at 0x000002437F375488>, 'divide': <function divide at 0x000002437F375510>, 'result': <map object at 0x000002437F398128>, 'myfunc1': <function myfunc1 at 0x000002437F375598>, 'myfunc2': <function myfunc2 at 0x000002437F375620>, 'f_1': <function f_1 at 0x000002437F3756A8>, 'f_2': <function f_2 at 0x000002437F375730>, 'f_22': <function f_22 at 0x000002437F3757B8>, 'f_3': <function f_3 at 0x000002437F375840>, 'f_4': <function f_4 at 0x000002437F3758C8>, 'order': <function order at 0x000002437F375950>, 'max': <function max at 0x000002437F3759D8>, 'min': <function min at 0x000002437F375A60>, 'sum': <function sum at 0x000002437F375AE8>, 'mean_0': <function mean_0 at 0x000002437F375B70>, 'mean': <function mean at 0x000002437F375BF8>, 'add_many': <function add_many at 0x000002437F375C80>, 'func': <function func at 0x000002437F375D08>, 'x': 10, 'y': 11, 'foo': <function foo at 0x000002437F375D90>, 'add_two': <function add_two at 0x000002437F375E18>, 'func_two': <function func_two at 0x000002437F375EA0>, 'foo2': <function foo2 at 0x000002437F375F28>, 'func_list': [<function add at 0x000002437F36AEA0>, <function subtract at 0x000002437F36AF28>, <function multiply at 0x000002437F375488>, <function divide at 0x000002437F375510>], 'a': <function add at 0x000002437F36AEA0>, 'b': <function add at 0x000002437F36AEA0>, 'add_new': <function <lambda> at 0x000002437F395048>, 'f1': <function f1 at 0x000002437F3950D0>, 'g': <function g at 0x000002437F395158>, 'multi_two': <function multi_two at 0x000002437F3951E0>, 'k': 254}

last_var = 20
last_list = [1,2,3,4]
print(locals())
# {'__name__': '__main__', '__doc__': '\ndef 함수명(매개변수):\n    <수행할 문장1>\n    <수행할 문장2>\n    ...\n    return 반환할값\n', '__package__': None, '__loader__': <_frozen_importlib_external.SourceFileLoader object at 0x000002C9B6D47390>, '__spec__': None, '__annotations__': {}, '__builtins__': <module 'builtins' (built-in)>, '__file__': 'C:/Users/CPB02GameN/PycharmProjects/Test01/04-1_함수.py', '__cached__': None, 'add_one_and_ten_time': <function add_one_and_ten_time at 0x000002C9B8A2ABF8>, 'add': <function add at 0x000002C9B8A2AEA0>, 'subtract': <function subtract at 0x000002C9B8A2AF28>, 'multiply': <function multiply at 0x000002C9B8A35488>, 'divide': <function divide at 0x000002C9B8A35510>, 'result': <map object at 0x000002C9B8A59128>, 'myfunc1': <function myfunc1 at 0x000002C9B8A35598>, 'myfunc2': <function myfunc2 at 0x000002C9B8A35620>, 'f_1': <function f_1 at 0x000002C9B8A356A8>, 'f_2': <function f_2 at 0x000002C9B8A35730>, 'f_22': <function f_22 at 0x000002C9B8A357B8>, 'f_3': <function f_3 at 0x000002C9B8A35840>, 'f_4': <function f_4 at 0x000002C9B8A358C8>, 'order': <function order at 0x000002C9B8A35950>, 'max': <function max at 0x000002C9B8A359D8>, 'min': <function min at 0x000002C9B8A35A60>, 'sum': <function sum at 0x000002C9B8A35AE8>, 'mean_0': <function mean_0 at 0x000002C9B8A35B70>, 'mean': <function mean at 0x000002C9B8A35BF8>, 'add_many': <function add_many at 0x000002C9B8A35C80>, 'func': <function func at 0x000002C9B8A35D08>, 'x': 10, 'y': 11, 'foo': <function foo at 0x000002C9B8A35D90>, 'add_two': <function add_two at 0x000002C9B8A35E18>, 'func_two': <function func_two at 0x000002C9B8A35EA0>, 'foo2': <function foo2 at 0x000002C9B8A35F28>, 'func_list': [<function add at 0x000002C9B8A2AEA0>, <function subtract at 0x000002C9B8A2AF28>, <function multiply at 0x000002C9B8A35488>, <function divide at 0x000002C9B8A35510>], 'a': <function add at 0x000002C9B8A2AEA0>, 'b': <function add at 0x000002C9B8A2AEA0>, 'add_new': <function <lambda> at 0x000002C9B8A55048>, 'f1': <function f1 at 0x000002C9B8A550D0>, 'g': <function g at 0x000002C9B8A55158>, 'multi_two': <function multi_two at 0x000002C9B8A551E0>, 'k': 254,
# 'last_var': 20, 'last_list': [1, 2, 3, 4]}




# 외장함수 ==> 파이선 데이터 분석 강의중에 다룬다

# # 리스트의 출력
# def printList(title,numberPerLine,prnList):
#     count = 0
#     print(title)
#     for k in prnList:
#         count = count + 1
#         print(k,end=' ')
#         if count % numberPerLine == 0:
#             print()
#
# title = '--성적테이블--'
# l = [0,1,2,3,4,5,6,7,8,9,10,11]
# number = 4
# printList(title,number,l)
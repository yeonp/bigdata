# calculator.py

# add()함수 정의


def add(a,b):
    c = a + b
    # print('add called!!')
    return c

# subtract()함수 정의
def subtract(a,b):
    c = a - b
    # print('subtract called!!')
    return c

# multiply()함수 정의
def multiply(a,b):
    c = a * b
    # print('multiply called!!')
    return c

# divide() 함수 정의
def divide(a,b):
    c = a / b
    # print('devide called!!')
    return c

if __name__ == '__main__':
    print(add(10, 20))
    print(subtract(30, 10))
    print('안녕하세요')

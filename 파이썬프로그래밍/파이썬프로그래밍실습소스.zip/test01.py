# test01.py

# 단축키 암기

# CTRL + / : 주석문 설정/해제
#
# # Tab : 들여쓰기(Indent)
# # Shift + Tab : 들여쓰기 해제(Unindent)
#
# # Shift + F10 : Run(기존 수행했던 소스코드를 실행)
# # CTRL + Shift + F10 : Run(새로작성된 소스코드를 실행)
# #  ==> 오른쪽  마우스 버튼을 클릭하여 실행
#
# # F8 : 디버거 모드에서 Step Over


a =10
a
print(a)
# input()

a = 10
b = 20
c = a + b
d = a * b
print(c)
print(d)

#
# a = input('a=')
# b = input('b=')
# c = int(a) + int(b)
# print(c)

# pass


def multi_two(x):
    return x*2
result = map(multi_two,[1,2,3,4,])
print(list(result))


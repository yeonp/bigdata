# 03-1_제어문.py

# if, for, while문

# if
a = 15

if a == 10 :
    print("a = 10")

if a == 10 :
    print("a = 10")
else:
    pass

if a > 5 :
    print("Big")
else:
    print("Small")

order = 'spagetti'
if order == 'spagetti':
    price = 5000
elif order == 'spam':
    price = 6000
elif order == 'egg':
    price = 7000
elif order == 'ham':
    price = 8000
else:
    price = 0

print("order price : %d"%price)

a = 10
if a > 5:
    x = a * 2
else:
    x = a /2
print(x)

x = a*2 if a > 5 else a/2
print(x)

t = (a/2, a*2)
index = a > 5
x = t[index]

x = (a/2, a*2)[a > 5]
print(x)

a = 10
x = {False:'짝수', True:'홀수'} [a%2].strip('수')
print(x)

# for문

for k in range(10):
    print(k)

l = [1,2,3,5,1,7,8,4,2,3]
for k in l:
    print(k)

l = ['cat','dog','bird','pig','tiger']
for i,k in enumerate(l): # enumerate:인덱스값도 반환
    print(i,k)
    if i == 3 :
        print('[3:%s]'%k)


# continue, break문
for x in range(1000):
    if x > 3 :
        break     # for문의 loop를 탈출
    print(x)

print('-'*50)

for x in range(10):
    if x < 3 :
        continue   # for문의 다음 문장을 skip하고
    print(x)       # for문의 시작부분으로 이동

l = ['cat','dog','bird','pig','tiger']
for x in l:
    if x == 'pig' :
        break     # for문의 loop를 탈출
    print(x)

l = ['cat','dog','bird','pig','tiger']
for x in range(len(l)):
    print(l[x])



# 중첩된(nested) for 문
for x in range(2,4):
    for y in range(1,10):
        print(x,'*',y,'=',x*y)

# while 문
a = 0
while a < 10 :
    print(a)
    a = a + 1

# while True :    # 무한 루프
#     print(a)
#     a = a + 1
a = 0
while True :
    print(a)
    a = a + 1
    if a == 1000:  break


a = [1,2,3,4]
a.insert(0,a)
print(a)  # [[...], 1, 2, 3, 4] , 순환 참조 리스트
print(a[0])
print(hex(id(a)))
print(hex(id(a[0][0][0])))